Imports System.IO

''' <summary>
''' Logica de vagas das garagens (2/6/10 carros), compartilhada pelas tres garagens.
''' As decisoes (PickSlot, PlanNormalize, PlanMove) sao funcoes PURAS, sem I/O, para serem testaveis;
''' as funcoes com I/O apenas aplicam o plano com validacao e rollback.
''' </summary>
Public Structure SlotEntry
    Public UniqueID As Integer
    Public Index As Integer
    Public Sub New(uid As Integer, idx As Integer)
        UniqueID = uid
        Index = idx
    End Sub
End Structure

Public Module GarageSlots

    ' ======================= PURE LOGIC =======================

    ''' <summary>
    ''' Escolhe a vaga para guardar um carro. Se o carro ja mora nesta garagem (hasSelf), mantem a vaga dele.
    ''' Devolve -1 se nao houver vaga livre (antes o mod devolvia a vaga "capacidade" ou 0, que ja estava ocupada).
    ''' </summary>
    Public Function PickSlot(entries As IEnumerable(Of SlotEntry), capacity As Integer, selfUid As Integer, hasSelf As Boolean) As Integer
        Dim used As New HashSet(Of Integer)
        Dim preferred As Integer = -1
        For Each e In entries
            If hasSelf AndAlso e.UniqueID = selfUid Then
                preferred = e.Index      ' o arquivo antigo deste carro sera apagado depois de salvar o novo
            Else
                used.Add(e.Index)
            End If
        Next
        If preferred >= 0 AndAlso preferred < capacity AndAlso Not used.Contains(preferred) Then Return preferred
        For i As Integer = 0 To capacity - 1
            If Not used.Contains(i) Then Return i
        Next
        Return -1
    End Function

    ''' <summary>Conserta vagas invalidas (fora de 0..capacidade-1) ou duplicadas. Devolve so as mudancas necessarias.</summary>
    Public Function PlanNormalize(entries As IEnumerable(Of SlotEntry), capacity As Integer) As List(Of SlotEntry)
        Dim changes As New List(Of SlotEntry)
        Dim seen As New HashSet(Of Integer)
        Dim toFix As New List(Of SlotEntry)
        For Each e In entries.OrderBy(Function(x) x.Index).ThenBy(Function(x) x.UniqueID)
            If e.Index >= 0 AndAlso e.Index < capacity AndAlso seen.Add(e.Index) Then Continue For
            toFix.Add(e)
        Next
        For Each e In toFix
            Dim free As Integer = -1
            For i As Integer = 0 To capacity - 1
                If Not seen.Contains(i) Then
                    free = i
                    Exit For
                End If
            Next
            If free < 0 Then Continue For   ' garagem realmente sem espaco: nao inventa vaga
            seen.Add(free)
            changes.Add(New SlotEntry(e.UniqueID, free))
        Next
        Return changes
    End Function

    ''' <summary>Plano para mover um carro para uma vaga: vaga vazia = so ele muda; vaga ocupada = os dois trocam.</summary>
    Public Function PlanMove(entries As IEnumerable(Of SlotEntry), moverUid As Integer, targetIndex As Integer) As List(Of SlotEntry)
        Dim changes As New List(Of SlotEntry)
        Dim list = entries.ToList()
        Dim mover As SlotEntry? = Nothing
        For Each e In list
            If e.UniqueID = moverUid Then
                mover = e
                Exit For
            End If
        Next
        If Not mover.HasValue OrElse mover.Value.Index = targetIndex Then Return changes
        For Each e In list
            If e.UniqueID <> moverUid AndAlso e.Index = targetIndex Then
                changes.Add(New SlotEntry(e.UniqueID, mover.Value.Index))   ' o ocupante assume a vaga antiga
                Exit For
            End If
        Next
        changes.Add(New SlotEntry(moverUid, targetIndex))
        Return changes
    End Function

    ' ======================= I/O (aplica o plano com validacao e rollback) =======================

    Private Function XmlPath(apt As ApartmentClass, uid As Integer) As String
        Return $"{grgXmlPath}{apt.GarageFilePath}\{uid}.xml"
    End Function

    Private Function ToEntries(list As List(Of VehicleClass)) As List(Of SlotEntry)
        Return list.Select(Function(v) New SlotEntry(v.UniqueID, v.Index)).ToList()
    End Function

    Private Function ApplyIndex(apt As ApartmentClass, vc As VehicleClass, newIndex As Integer) As Boolean
        Dim vd As New VehicleData(XmlPath(apt, vc.UniqueID), vc)
        vd.Index = newIndex
        Return vd.Save()
    End Function

    ''' <summary>Vaga para guardar um carro nesta garagem, ou -1 se estiver cheia.</summary>
    Public Function GetSlotForSave(apt As ApartmentClass, capacity As Integer, fromApartment As Integer, uniqueId As Integer) As Integer
        Dim hasSelf As Boolean = (fromApartment = apt.ID AndAlso uniqueId <> 0)
        Return PickSlot(ToEntries(apt.Vehicles), capacity, uniqueId, hasSelf)
    End Function

    ''' <summary>Move (ou troca) de forma segura. Se uma gravacao falhar, desfaz as anteriores e devolve False.</summary>
    Public Function MoveToSlot(apt As ApartmentClass, mover As VehicleClass, targetIndex As Integer) As Boolean
        Try
            Dim list As List(Of VehicleClass) = apt.Vehicles
            Dim changes = PlanMove(ToEntries(list), mover.UniqueID, targetIndex)
            If changes.Count = 0 Then Return True

            Dim applied As New List(Of KeyValuePair(Of VehicleClass, Integer))   ' carro, indice antigo
            For Each ch In changes
                Dim vc As VehicleClass = list.Find(Function(v) v.UniqueID = ch.UniqueID)
                If vc Is Nothing OrElse Not ApplyIndex(apt, vc, ch.Index) Then
                    For i As Integer = applied.Count - 1 To 0 Step -1
                        ApplyIndex(apt, applied(i).Key, applied(i).Value)
                    Next
                    Logger.Log($"MoveToSlot: falhou ao gravar {ch.UniqueID}; mudancas anteriores desfeitas")
                    Return False
                End If
                applied.Add(New KeyValuePair(Of VehicleClass, Integer)(vc, vc.Index))
            Next
            Return True
        Catch ex As Exception
            Logger.Log($"MoveToSlot: {ex.Message} {ex.StackTrace}")
            Return False
        End Try
    End Function

    ''' <summary>Auto-cura: garagens com vagas duplicadas/invalidas (ex.: salvas pelo bug antigo) sao consertadas ao carregar.</summary>
    Public Sub NormalizeSlots(apt As ApartmentClass, capacity As Integer)
        Try
            Dim list As List(Of VehicleClass) = apt.Vehicles
            For Each ch In PlanNormalize(ToEntries(list), capacity)
                Dim vc As VehicleClass = list.Find(Function(v) v.UniqueID = ch.UniqueID)
                If vc Is Nothing Then Continue For
                Dim oldIdx As Integer = vc.Index
                If ApplyIndex(apt, vc, ch.Index) Then
                    Logger.Log($"Garagem {apt.Name}: carro {vc.UniqueID} estava na vaga {oldIdx} (invalida/duplicada); movido para {ch.Index}")
                End If
            Next
        Catch ex As Exception
            Logger.Log($"NormalizeSlots: {ex.Message} {ex.StackTrace}")
        End Try
    End Sub

End Module
