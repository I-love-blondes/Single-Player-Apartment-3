Imports System.Drawing
Imports System.IO
Imports System.Runtime.CompilerServices
Imports GTA
Imports GTA.Math
Imports SPAII.Compat
Imports GTA.UI
Imports SPAII.INM

Module TwoCarGarage

    Public Apartment As ApartmentClass = Nothing
    Public WithEvents MgmtMenu, MgmtOptMenu, MgmtMoveMenu As UIMenu
    Public Camera As Camera
    Public MgmtSelVeh As VehClassMenuItem = Nothing

    'Vehicle
    Public Vehicle0 As Vehicle
    Public Vehicle1 As Vehicle
    Public Vehicles As New List(Of Vehicle)

    'Coords
    Public Interior As New Vector3(173.1176F, -1003.27887F, -99)
    Public Elevator As New Vector3(179.1001, -1005.655, -99.9999)
    Public ElevatorInside As New Quaternion(179.0661F, -1002.717F, -99.99992F, 179.181F)
    Public SpawnInPos As New Quaternion(176.6249F, -1007.737F, -99.9999F, 32.54933F)
    Public GarageDoor As New Vector3(172.9447, -1008.339, -99.9999)
    Public MenuActivator As New Vector3(178.9034F, -1007.407F, -99.99998F)
    Public Veh0Pos As New Quaternion(175.2132, -1004.104, -99.99999, -178.4487)
    Public Veh1Pos As New Quaternion(171.7141, -1004.023, -99.99999, -178.4487)
    Public MenuCam As New CameraPRH(New Vector3(179.6135F, -1008.107F, -97.29996F), New Vector3(-24.14237F, 0F, 57.91766F), 50.0F)

    Public Sub LoadGarageMenu()
        MgmtMenu = New UIMenu("", Game.GetLocalizedString("MP_MAN_VEH0").ToUpper, New Point(0, -107))
        With MgmtMenu
            .SetBannerType(MenuBanner)
            .MouseEdgeEnabled = False
            MenuPool.Add(MgmtMenu)
            .RefreshIndex()
        End With

        MgmtOptMenu = New UIMenu("", Game.GetLocalizedString("MP_MAN_VEH0").ToUpper, New Point(0, -107))
        With MgmtOptMenu
            .SetBannerType(MenuBanner)
            .MouseEdgeEnabled = False
            MenuPool.Add(MgmtOptMenu)
            .RefreshIndex()
        End With

        MgmtMoveMenu = New UIMenu("", Game.GetLocalizedString("MP_MAN_VEH0").ToUpper, New Point(0, -107))
        With MgmtMoveMenu
            .SetBannerType(MenuBanner)
            .MouseEdgeEnabled = False
            MenuPool.Add(MgmtMoveMenu)
            .RefreshIndex()
        End With
    End Sub

    Public Sub RefreshOptMenu()
        MgmtOptMenu.MenuItems.Clear()

        With MgmtOptMenu
            Dim move As New UIMenuItem(Game.GetLocalizedString("MP_MAN_VEH2")) With {.Tag = "Move"}
            .AddItem(move)
            MgmtMenu.BindMenuToItem(MgmtOptMenu, move)
            Dim remove As New UIMenuItem(Game.GetLocalizedString("ITEM_REM")) With {.Tag = "Remove"}
            .AddItem(remove)
            MgmtMenu.BindMenuToItem(MgmtOptMenu, remove)
            Dim plate As New UIMenuItem(Game.GetLocalizedString("CMOD_MOD_PLA")) With {.Tag = "Plate"}
            .AddItem(plate) 'Change Plate
            MgmtMenu.BindMenuToItem(MgmtOptMenu, plate)
            .RefreshIndex()
        End With
    End Sub

    Public Sub RefreshMgmtMenu(Optional itemDesc As String = "MP_MAN_VEH3")
        MgmtMenu.MenuItems.Clear()

        With MgmtMenu
            Dim veh1 As VehicleClass = Apartment.Vehicles.Find(Function(x) x.Index = 0)
            Dim item1 As New UIMenuItem(If(veh1 Is Nothing, Game.GetLocalizedString("MP_MAN_VEH_S"), $"{veh1.Make} {veh1.Name} ({veh1.PlateNumber})"), Game.GetLocalizedString(itemDesc)) With {.Tag = New VehClassMenuItem(0, veh1), .Enabled = If(veh1 Is Nothing, False, True)}
            .AddItem(item1)
            Dim veh2 As VehicleClass = Apartment.Vehicles.Find(Function(x) x.Index = 1)
            Dim item2 As New UIMenuItem(If(veh2 Is Nothing, Game.GetLocalizedString("MP_MAN_VEH_S"), $"{veh2.Make} {veh2.Name} ({veh2.PlateNumber})"), Game.GetLocalizedString(itemDesc)) With {.Tag = New VehClassMenuItem(1, veh2), .Enabled = If(veh2 Is Nothing, False, True)}
            .AddItem(item2)
            .RefreshIndex()
        End With
    End Sub

    Public Sub RefreshMoveMenu(Optional itemDesc As String = "MP_MAN_VEH3")
        MgmtMoveMenu.MenuItems.Clear()

        With MgmtMoveMenu
            Dim veh1 As VehicleClass = Apartment.Vehicles.Find(Function(x) x.Index = 0)
            Dim item1 As New UIMenuItem(If(veh1 Is Nothing, Game.GetLocalizedString("MP_MAN_VEH_S"), $"{veh1.Make} {veh1.Name} ({veh1.PlateNumber})"), Game.GetLocalizedString(itemDesc)) With {.Tag = New VehClassMenuItem(0, If(veh1 Is Nothing, Nothing, veh1))}
            .AddItem(item1)
            MgmtOptMenu.BindMenuToItem(MgmtMoveMenu, item1)
            Dim veh2 As VehicleClass = Apartment.Vehicles.Find(Function(x) x.Index = 1)
            Dim item2 As New UIMenuItem(If(veh2 Is Nothing, Game.GetLocalizedString("MP_MAN_VEH_S"), $"{veh2.Make} {veh2.Name} ({veh2.PlateNumber})"), Game.GetLocalizedString(itemDesc)) With {.Tag = New VehClassMenuItem(1, If(veh2 Is Nothing, Nothing, veh2))}
            .AddItem(item2)
            MgmtOptMenu.BindMenuToItem(MgmtMoveMenu, item2)
            .RefreshIndex()
        End With
    End Sub

    Public Sub LoadVehicles()
        Try
            NormalizeSlots(Apartment, 2)
            Vehicles.Clear()
            If Vehicle0 <> Nothing Then VehicleTags.ForgetAndDelete(Vehicle0)
            If Vehicle1 <> Nothing Then VehicleTags.ForgetAndDelete(Vehicle1)

            For Each veh In Apartment.Vehicles
                Try   ' uma falha (ex.: DLC ausente) nao impede os demais carros
                    If Not IsGarageVehicleAlreadyExistInWorldMap(Apartment.ID, veh.UniqueID) Then
                        Select Case veh.Index
                            Case 0
                                Vehicle0 = CreateGarageVehicle(veh, Veh0Pos, Apartment.ID)
                                If Vehicle0 IsNot Nothing Then
                                    Vehicle0.PlaceOnGround()
                                    Vehicles.Add(Vehicle0)
                                End If
                            Case 1
                                Vehicle1 = CreateGarageVehicle(veh, Veh1Pos, Apartment.ID)
                                If Vehicle1 IsNot Nothing Then
                                    Vehicle1.PlaceOnGround()
                                    Vehicles.Add(Vehicle1)
                                End If
                        End Select
                    End If
                Catch ex As Exception
                    Logger.Log($"LoadVehicles uid {veh.UniqueID}: {ex.Message} {ex.StackTrace}")
                End Try
            Next

            'TwoCarGarage Only
            TurnOffRadio("SE_MP_GARAGE_S_RADIO")
        Catch ex As Exception
            Logger.Log($"{ex.Message} {ex.StackTrace}")
        End Try
    End Sub

    Public Sub LoadVehiclesSetPlayerPos(uid As Integer)
        Try
            LoadVehicles()

            Dim target As Vehicle = Vehicles.Find(Function(x) x.GetInt(vehUidDecor) = uid)
            If target IsNot Nothing AndAlso target.Exists() Then
                Game.Player.Character.Position = target.Position
                target.SetPlayerIntoVehicle
            End If
        Catch ex As Exception
            Logger.Log($"{ex.Message} {ex.StackTrace}")
        End Try
    End Sub

    Public Function GarageElevatorDistance() As Single
        Return Game.Player.Character.Position.DistanceToSquared(Elevator)
    End Function

    Public Function GarageDoorLeftDistance() As Single
        Return Game.Player.Character.Position.DistanceToSquared(GarageDoor)
    End Function

    Public Function MenuDistance() As Single
        Return Game.Player.Character.Position.DistanceToSquared(MenuActivator)
    End Function

    Public Sub TwoCarGarageOnTick()
        If PI = TwoCarGarage.Interior.GetInterior Then
            If Vehicles.Count <> 0 Then
                If Game.IsControlPressed(Control.MultiplayerInfo) Then
                    If Vehicle0 <> Nothing Then StatScaleform0.DrawMPCarStats(Vehicle0)
                    If Vehicle1 <> Nothing Then StatScaleform1.DrawMPCarStats(Vehicle1)
                End If
            End If

            'Vehicle Management
            If MenuDistance() <= 2.0F Then
                If Not MenuPool.IsAnyMenuOpen Then
                    ShowHelp(Game.GetLocalizedString("MP_MAN_VEH"))
                    If Game.IsControlJustReleased(Control.Context) Then
                        RefreshMgmtMenu()
                        MgmtMenu.Visible = True
                        HideHud = True
                        Camera = World.CreateCamera(MenuCam.Position, MenuCam.Rotation, MenuCam.FOV)
                        World.RenderingCamera = Camera
                        GarageMarkerIndicator = Veh0Pos.ToVector3
                        Camera.PointAt(GarageMarkerIndicator)
                    End If
                End If
            End If

            'Enter Apartment from Garage Elevator
            If GarageElevatorDistance() <= 2.0F Then
                If Not Apartment.ApartmentType = eApartmentType.Other Then
                    ShowHelp(Game.GetLocalizedString("MP_PROP_BUZZ1"))
                    If Game.IsControlJustReleased(Control.Context) Then
                        HideHud = True
                        Apartment.Building.PlayEnterElevatorCutScene(5000)
                        Apartment.SetInteriorActive()
                        Game.Player.Character.Position = Apartment.ApartmentInPos
                        Select Case Apartment.ApartmentType
                            Case eApartmentType.LowEnd
                                LowEndApartment.Apartment = Apartment
                                LowEndApartment.SpawnDoor()
                            Case eApartmentType.MediumEnd
                                MediumEndApartment.Apartment = Apartment
                                MediumEndApartment.SpawnDoor()
                            Case eApartmentType.None, eApartmentType.IPL, eApartmentType.IPLwoStyle
                                HighEndApartment.Building = Apartment.Building
                        End Select
                        Apartment.PlayApartmentEnterCutscene()
                        Clear()
                        World.DestroyAllCameras()
                        World.RenderingCamera = Nothing
                        HideHud = False
                        Apartment = Nothing
                    End If
                End If
            End If

            'Exit Garage
            If GarageDoorLeftDistance() <= 2.0F Then
                GarageTransition.ExitOnFoot(Apartment.Building)
                Clear()
                Apartment = Nothing
            End If

            'Exit Garage with vehicle
            If Game.Player.Character.IsInVehicle Then
                If Vehicles.Contains(Game.Player.Character.CurrentVehicle) AndAlso Game.Player.Character.CurrentVehicle.Speed >= 0.5 Then
                    GarageTransition.BeginLoading()

                    Audio.PlaySoundAt(PP, "GARAGE_DOOR_SCRIPTED_CLOSE")
                    Dim curVeh As Vehicle = Vehicles.Find(Function(x) x.GetInt(vehUidDecor) = Game.Player.Character.CurrentVehicle.GetInt(vehUidDecor) AndAlso x.GetInt(vehIdDecor) = Apartment.ID)
                    Dim bd = Apartment.Building

                    Dim newVeh As Vehicle
                    ' O carro sai direto para a rua (GarageOutPos), parado, em vez de ser "dirigido" pela IA ate la
                    Game.Player.Character.Position = bd.GarageOutPos.ToVector3
                    newVeh = curVeh.CloneVehicle(bd.GarageOutPos.ToVector3, bd.GarageOutPos.W, False)
                    With newVeh
                        .AddBlip()
                        .AttachedBlip.Sprite = newVeh.Model.GetProperBlipSprite
                        Select Case GetPlayer()
                            Case eOwner.Michael
                                .AttachedBlip.Color = BlipColor.Michael
                            Case eOwner.Franklin
                                .AttachedBlip.Color = BlipColor.Franklin
                            Case eOwner.Trevor
                                .AttachedBlip.Color = BlipColor.Trevor
                            Case eOwner.Others
                                .AttachedBlip.Color = BlipColor.Yellow
                        End Select
                        .AttachedBlip.IsShortRange = True
                        .AttachedBlip.Name = $"{newVeh.Make} {newVeh.FriendlyName}"
                        .PlaceOnGround()
                    End With
                    outVehicleList.Add(newVeh)
                    newVeh.Position = bd.GarageOutPos.ToVector3
                    newVeh.SetPlayerIntoVehicle
                    newVeh.IsEngineRunning = True
                    Clear()
                    GarageTransition.FinishVehicleExit(newVeh, bd.GarageOutPos.W)
                    Apartment = Nothing
                End If
            End If

            'Draw marker
            If MenuDistance() <= 200.0F AndAlso Not Apartment Is Nothing Then MenuActivator.DrawMarker
            If MgmtMenu.Visible Or MgmtOptMenu.Visible Or MgmtMoveMenu.Visible Then GarageMarkerIndicator.DrawMgmtMarker
        End If
    End Sub

    Private Sub MgmtMenu_OnIndexChange(sender As UIMenu, Index As Integer) Handles MgmtMenu.OnIndexChange, MgmtMoveMenu.OnIndexChange
        Dim selectedItem As UIMenuItem = sender.MenuItems(Index)
        Dim selectedVeh As VehClassMenuItem = TryCast(selectedItem.Tag, VehClassMenuItem)
        If selectedVeh Is Nothing OrElse Camera Is Nothing Then Return

        Select Case selectedVeh.Index
            Case 0
                GarageMarkerIndicator = Veh0Pos.ToVector3
            Case 1
                GarageMarkerIndicator = Veh1Pos.ToVector3
        End Select

        Camera.PointAt(GarageMarkerIndicator)
    End Sub

    Private Sub MgmtMenu_OnItemSelect(sender As UIMenu, selectedItem As UIMenuItem, index As Integer) Handles MgmtMenu.OnItemSelect
        Dim picked As VehClassMenuItem = TryCast(selectedItem.Tag, VehClassMenuItem)
        If picked Is Nothing OrElse picked.VehClass Is Nothing Then Return   ' vaga vazia: nada para gerenciar
        MgmtSelVeh = picked
        RefreshOptMenu()
        MgmtOptMenu.Visible = True
        sender.Visible = False
    End Sub

    Private Sub MgmtMenu_OnMenuClose(sender As UIMenu) Handles MgmtMenu.OnMenuClose
        World.DestroyAllCameras()
        World.RenderingCamera = Nothing
        HideHud = False
    End Sub

    Private Sub MgmtOptMenu_OnItemSelect(sender As UIMenu, selectedItem As UIMenuItem, index As Integer) Handles MgmtOptMenu.OnItemSelect
        If MgmtSelVeh IsNot Nothing Then
            Select Case selectedItem.Tag
                Case "Move"
                    RefreshMoveMenu()
                    MgmtMoveMenu.Visible = True
                    sender.Visible = False
                    SyncMarker(MgmtMoveMenu)
                Case "Remove"
                    Dim ExistingFileToDelete As String = $"{grgXmlPath}{Apartment.GarageFilePath}\{MgmtSelVeh.VehClass.UniqueID}.xml"
                    If File.Exists(ExistingFileToDelete) Then
                        File.Delete(ExistingFileToDelete)
                        LoadVehicles()
                        MgmtSelVeh = Nothing
                        RefreshMgmtMenu()
                        sender.GoBack()
                        SyncMarker(MgmtMenu)
                    End If
                Case "Plate"
                    Dim plateText As String = Game.GetUserInput("FMMC_KEY_TIP8", MgmtSelVeh.VehClass.PlateNumber, 8)
                    If plateText <> "" Then
                        Dim vc As VehicleClass = MgmtSelVeh.VehClass
                        Dim vd As New VehicleData($"{grgXmlPath}{Apartment.GarageFilePath}\{vc.UniqueID}.xml", vc)
                        vd.PlateNumber = plateText.ToUpper.TruncateString(8)
                        vd.Save()
                        LoadVehicles()
                        MgmtSelVeh = Nothing
                        RefreshMgmtMenu()
                        sender.GoBack()
                        SyncMarker(MgmtMenu)
                    End If
            End Select
        Else
            sender.GoBack()
                        SyncMarker(MgmtMenu)
        End If
    End Sub

    Private Sub MgmtMoveMenu_OnItemSelect(sender As UIMenu, selectedItem As UIMenuItem, index As Integer) Handles MgmtMoveMenu.OnItemSelect
        Try
            If MgmtSelVeh IsNot Nothing AndAlso MgmtSelVeh.VehClass IsNot Nothing Then
                Dim picked As VehClassMenuItem = TryCast(selectedItem.Tag, VehClassMenuItem)
                If picked IsNot Nothing Then
                    ' Move/troca com validacao e rollback (se a 2a gravacao falhar, a 1a e desfeita)
                    If Not MoveToSlot(Apartment, MgmtSelVeh.VehClass, picked.Index) Then
                        Screen.ShowSubtitle("~r~Could not move vehicle")
                    End If
                End If

                LoadVehicles()
                MgmtSelVeh = Nothing
                RefreshMgmtMenu()
                MgmtMenu.Visible = True
                sender.Visible = False
                SyncMarker(MgmtMenu)
            End If
        Catch ex As Exception
            Logger.Log($"{ex.Message} {ex.StackTrace}")
        End Try
    End Sub

    ' Ao (re)abrir um menu o LemonUI nao dispara o evento de indice: alinha o marcador/camera com a selecao atual.
    Private Sub SyncMarker(menu As UIMenu)
        Try
            If menu Is Nothing OrElse menu.MenuItems.Count = 0 Then Return
            Dim i As Integer = System.Math.Max(0, System.Math.Min(menu.CurrentSelection, menu.MenuItems.Count - 1))
            MgmtMenu_OnIndexChange(menu, i)
        Catch ex As Exception
            Logger.Log($"SyncMarker: {ex.Message}")
        End Try
    End Sub

    Public Sub Clear()
        If Vehicle0 <> Nothing Then VehicleTags.ForgetAndDelete(Vehicle0)
        If Vehicle1 <> Nothing Then VehicleTags.ForgetAndDelete(Vehicle1)
    End Sub

End Module
