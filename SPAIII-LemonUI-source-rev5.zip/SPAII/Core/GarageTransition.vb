Imports GTA
Imports GTA.Math
Imports GTA.Native
Imports GTA.UI
Imports NFunc = GTA.Native.Function

''' <summary>
''' Entrada e saida de garagem sem cena de camera: a tela escurece com um indicador "Loading", o jogo espera o mundo/interior
''' e os carros carregarem (com tempo limite) e so entao a tela volta.
''' Substitui PlayEnterGarageCamera/PlayExitGarageCamera, que montavam uma sequencia de direcao automatica (DriveTo) e
''' nunca a cancelavam: o carro seguia dirigindo sozinho depois da saida.
''' </summary>
Public Module GarageTransition

    Private _loading As Boolean = False
    Private Const WorldTimeoutMs As Integer = 8000

    Public ReadOnly Property IsLoading As Boolean
        Get
            Return _loading
        End Get
    End Property

    ''' <summary>Escurece a tela e mostra o indicador de carregamento.</summary>
    Public Sub BeginLoading()
        If _loading Then Return
        _loading = True
        Try
            HideHud = True
            FadeScreen(1, 500)
            LoadingPrompt.Show("Loading...", LoadingSpinnerType.RegularClockwise)
        Catch ex As Exception
            Logger.Log($"GarageTransition.BeginLoading: {ex.Message}")
        End Try
    End Sub

    ''' <summary>
    ''' Espera o mundo em volta de <paramref name="pos"/> carregar (colisao + cena), mantendo a entidade congelada para
    ''' nao cair nem escorregar, ate o limite de tempo.
    ''' </summary>
    Public Sub WaitForWorld(pos As Vector3, entity As Entity, Optional timeoutMs As Integer = WorldTimeoutMs)
        Dim frozen As Boolean = False
        Try
            If entity IsNot Nothing AndAlso entity.Exists() Then
                entity.IsPositionFrozen = True
                frozen = True
            End If
            NFunc.Call(Hash.NEW_LOAD_SCENE_START_SPHERE, pos.X, pos.Y, pos.Z, 60.0F, 0)

            Dim deadline = Date.UtcNow.AddMilliseconds(timeoutMs)
            Do
                NFunc.Call(Hash.REQUEST_COLLISION_AT_COORD, pos.X, pos.Y, pos.Z)
                Dim collisionOk As Boolean = (entity Is Nothing) OrElse Not entity.Exists() OrElse
                    NFunc.Call(Of Boolean)(Hash.HAS_COLLISION_LOADED_AROUND_ENTITY, entity.Handle)
                Dim sceneOk As Boolean = NFunc.Call(Of Boolean)(Hash.IS_NEW_LOAD_SCENE_LOADED)
                If collisionOk AndAlso sceneOk Then Exit Do
                If Date.UtcNow > deadline Then
                    Logger.Log($"GarageTransition: o mundo nao carregou em {timeoutMs} ms; continuando mesmo assim")
                    Exit Do
                End If
                Script.Yield()
            Loop
        Catch ex As Exception
            Logger.Log($"GarageTransition.WaitForWorld: {ex.Message} {ex.StackTrace}")
        Finally
            Try
                NFunc.Call(Hash.NEW_LOAD_SCENE_STOP)
                If frozen AndAlso entity.Exists() Then
                    Dim veh As Vehicle = TryCast(entity, Vehicle)
                    If veh IsNot Nothing Then veh.PlaceOnGround()
                    entity.IsPositionFrozen = False
                End If
            Catch ex As Exception
                Logger.Log($"GarageTransition.WaitForWorld(finally): {ex.Message}")
            End Try
        End Try
    End Sub

    ''' <summary>Espera o mundo em volta da entidade carregar, esconde o indicador e devolve a tela.</summary>
    Public Sub EndLoading(Optional entity As Entity = Nothing)
        Try
            If entity IsNot Nothing AndAlso entity.Exists() Then WaitForWorld(entity.Position, entity)
        Catch ex As Exception
            Logger.Log($"GarageTransition.EndLoading: {ex.Message}")
        End Try
        Finish()
    End Sub

    Private Sub Finish()
        Try
            If LoadingPrompt.IsActive Then LoadingPrompt.Hide()
        Catch
        End Try
        Try
            World.DestroyAllCameras()
            World.RenderingCamera = Nothing
            HideHud = False
            FadeScreen(0, 500)
        Catch ex As Exception
            Logger.Log($"GarageTransition.Finish: {ex.Message}")
        End Try
        _loading = False
    End Sub

    ''' <summary>Rede de seguranca: se algo falhar no meio, nunca deixa a tela presa no preto nem o indicador ligado.</summary>
    Public Sub AbortLoading()
        If Not _loading Then Return
        Logger.Log("GarageTransition: carregamento abortado; restaurando a tela")
        Finish()
    End Sub

    ''' <summary>Sai da garagem a pe: teleporta para fora, espera carregar e mostra a tela.</summary>
    Public Sub ExitOnFoot(bd As BuildingClass)
        Dim ped As Ped = Game.Player.Character
        BeginLoading()
        Try
            If bd.GarageDoor = eFrontDoor.StandardDoor Then
                ped.Position = bd.GarageInPos
                ped.Heading = bd.GarageFootOutPos.W
            Else
                Audio.PlaySoundAt(ped, "GARAGE_DOOR_SCRIPTED_CLOSE")
                ped.Position = bd.GarageOutPos.ToVector3
                ped.Heading = bd.GarageOutPos.W
            End If
        Catch ex As Exception
            Logger.Log($"GarageTransition.ExitOnFoot: {ex.Message} {ex.StackTrace}")
        End Try
        EndLoading(ped)
    End Sub

    ''' <summary>
    ''' Fecha a saida com veiculo: o carro ja foi colocado fora da garagem. Garante que ele esteja PARADO e sem nenhuma tarefa
    ''' de direcao automatica, espera o mundo carregar e so entao mostra a tela.
    ''' </summary>
    Public Sub FinishVehicleExit(veh As Vehicle, heading As Single)
        Dim ped As Ped = Game.Player.Character
        Try
            If veh IsNot Nothing AndAlso veh.Exists() Then
                veh.Heading = heading
                ped.Task.ClearAll()
                veh.Speed = 0.0F
                veh.IsEngineRunning = True
            End If
        Catch ex As Exception
            Logger.Log($"GarageTransition.FinishVehicleExit: {ex.Message} {ex.StackTrace}")
        End Try
        EndLoading(veh)
        Try
            If veh IsNot Nothing AndAlso veh.Exists() Then veh.Speed = 0.0F
        Catch
        End Try
    End Sub

End Module
