Imports System.Drawing
Imports System.IO
Imports GTA
Imports GTA.Math
Imports GTA.Native
Imports SPAII.Compat
Imports GTA.UI
Imports SPAII.INM
Imports NFunc = GTA.Native.Function

Public Class BuildingClass

    Public Name As String
    ''' <summary>
    ''' a.k.a Entrance in SPA
    ''' </summary>
    Public BuildingInPos As Quaternion
    Public BuildingLobby As Quaternion
    ''' <summary>
    ''' a.k.a TeleportOutside in SPA
    ''' </summary>
    Public BuildingOutPos As Quaternion
    Public GarageInPos As Vector3
    Public GarageFootInPos As Quaternion
    Public GarageFootOutPos As Quaternion
    Public GarageOutPos As Quaternion
    Public CameraPos As CameraPRH
    Public EnterCamera1, EnterCamera2, EnterCamera3, EnterCamera4 As CameraPRH
    Public GarageType As eGarageType
    Public BuildingType As eBuildingType
    Public Apartments As List(Of ApartmentClass)
    Public HideObjects() As String
    Public SaleSign As EntityVector
    Public FrontDoor As eFrontDoor
    Public Door1 As Door
    Public Door2 As Door
    Public GarageDoor As eFrontDoor
    Public Door3 As Door
    Public GarageWaypoint As Quaternion

    Public BuildingBlip As Blip
    Public GarageBlip As Blip
    Public SaleSignProp As Prop

    Public WithEvents BuyMenu As UIMenu
    Public WithEvents AptMenu As UIMenu
    Public WithEvents GrgMenu As UIMenu

    Public Sub New()

    End Sub

    Public Function IsVacant() As Boolean
        Dim apt = (From a In Apartments Where a.Owner <> eOwner.Nobody Select a)
        Return apt.Count = 0
    End Function

    Public RuntimeLoaded As Boolean = False

    ' Registro leve no startup: so dados + blips (sem menus, props ou interiores).
    Public Sub Register()
        For Each apt In Apartments
            If Not Helper.apartments.Contains(apt) Then Helper.apartments.Add(apt)
        Next
        CreateBlips()
    End Sub

    Public Sub RemoveBlips()
        If BuildingBlip IsNot Nothing Then
            If BuildingBlip.Exists() Then BuildingBlip.Delete()
            BuildingBlip = Nothing
        End If
        If GarageBlip IsNot Nothing Then
            If GarageBlip.Exists() Then GarageBlip.Delete()
            GarageBlip = Nothing
        End If
    End Sub

    ' Cria os blips do predio. Idempotente: remove os antigos antes (o original duplicava blips a cada refresh).
    Public Sub CreateBlips()
        RemoveBlips()
        If Not IsVacant() AndAlso Not BuildingType = eBuildingType.Garage Then
            GarageBlip = World.CreateBlip(GarageInPos)
            With GarageBlip
                .IsShortRange = True
                .Sprite = BlipSprite.Garage
                .Name = Game.GetLocalizedString("BLIP_357")
                .Color = GetBlipColor
            End With
        End If

        BuildingBlip = World.CreateBlip(BuildingInPos.ToVector3)
        With BuildingBlip
            .IsShortRange = True
            If IsVacant() Then
                If Not DebugMode Then
                    Select Case BuildingType
                        Case eBuildingType.Apartment
                            .Sprite = BlipSprite.SafehouseForSale
                            .Name = Game.GetLocalizedString("MP_PROP_SALE1") 'Apartment For Sale
                        Case eBuildingType.Office
                            .Sprite = BlipSprite.OfficeForSale
                            .Name = Game.GetLocalizedString("MP_PROP_SALE2") 'Office For Sale
                        Case eBuildingType.ClubHouse, eBuildingType.NightClub, eBuildingType.Bunker
                            .Sprite = BlipSprite.BusinessForSale
                            .Name = Game.GetLocalizedString("BLIP_373") 'Property For Sale
                        Case eBuildingType.Garage
                            .Sprite = BlipSprite.GarageForSale
                            .Name = Game.GetLocalizedString("MP_PROP_SALE0") 'Garage For Sale
                        Case eBuildingType.Hangar
                            .Sprite = BlipSprite.HangarForSale
                            .Name = Game.GetLocalizedString("BLIP_372") 'Hangar For Sale
                        Case eBuildingType.Warehouse
                            .Sprite = BlipSprite.WarehouseForSale
                            .Name = Game.GetLocalizedString("BLIP_474") 'Warehouse For Sale
                    End Select
                Else
                    Select Case BuildingType
                        Case eBuildingType.Apartment
                            .Sprite = BlipSprite.Safehouse
                        Case eBuildingType.Office
                            .Sprite = BlipSprite.Office
                        Case eBuildingType.ClubHouse
                            .Sprite = BlipSprite.BikerClubhouse
                        Case eBuildingType.Garage
                            .Sprite = BlipSprite.Garage
                        Case eBuildingType.Hangar
                            .Sprite = BlipSprite.GTAOHangar
                        Case eBuildingType.NightClub
                            .Sprite = BlipSprite.NightclubProperty
                        Case eBuildingType.Warehouse
                            .Sprite = BlipSprite.Warehouse
                        Case eBuildingType.Bunker
                            .Sprite = BlipSprite.Bunker
                    End Select
                    .Name = Name
                End If
                .Color = BlipColor.White
            Else
                Select Case BuildingType
                    Case eBuildingType.Apartment
                        .Sprite = BlipSprite.Safehouse
                        .Name = Game.GetLocalizedString("CELL_2630")
                    Case eBuildingType.Office
                        .Sprite = BlipSprite.Office
                        .Name = Game.GetLocalizedString("BLIP_475")
                    Case eBuildingType.ClubHouse
                        .Sprite = BlipSprite.BikerClubhouse
                        .Name = Game.GetLocalizedString("PM_SPAWN_CLUBH")
                    Case eBuildingType.Garage
                        .Sprite = BlipSprite.Garage
                        .Name = Game.GetLocalizedString("BLIP_357")
                    Case eBuildingType.Hangar
                        .Sprite = BlipSprite.GTAOHangar
                        .Name = Game.GetLocalizedString("BLIP_359")
                    Case eBuildingType.NightClub
                        .Sprite = BlipSprite.NightclubProperty
                        .Name = Game.GetLocalizedString("CELL_CLUB")
                    Case eBuildingType.Warehouse
                        .Sprite = BlipSprite.Warehouse
                        .Name = Game.GetLocalizedString("BLIP_473")
                    Case eBuildingType.Bunker
                        .Sprite = BlipSprite.Bunker
                        .Name = Game.GetLocalizedString("BLIP_557")
                End Select
                .Color = GetBlipColor
            End If
        End With
    End Sub

    ' Distancia ao quadrado do ponto mais proximo do predio (entrada, garagem, placa).
    Public Function DistanceSquaredFrom(p As Vector3) As Single
        Dim best As Single = Single.MaxValue
        Dim d As Single
        Dim e As Vector3 = BuildingInPos.ToVector3
        If e <> Vector3.Zero Then
            d = p.DistanceToSquared(e)
            If d < best Then best = d
        End If
        If GarageInPos <> Vector3.Zero Then
            d = p.DistanceToSquared(GarageInPos)
            If d < best Then best = d
        End If
        Dim f As Vector3 = GarageFootInPos.ToVector3
        If f <> Vector3.Zero Then
            d = p.DistanceToSquared(f)
            If d < best Then best = d
        End If
        Dim sgn As Vector3 = SaleSign.Position.ToVector3
        If sgn <> Vector3.Zero Then
            d = p.DistanceToSquared(sgn)
            If d < best Then best = d
        End If
        Return best
    End Function

    ' Cria menus, placa de venda e trava portas. So e chamado quando o jogador chega perto.
    Public Sub LoadRuntime()
        If RuntimeLoaded Then Return
        Try
        BuyMenu = New UIMenu("", Game.GetLocalizedString("MP_PROP_GEN0"), New Point(0, -107))
        BuyMenu.SetBannerType(MenuBanner)
        BuyMenu.MouseEdgeEnabled = False
        MenuPool.Add(BuyMenu)
        With BuyMenu
            For Each apt As ApartmentClass In Apartments
                Dim item As New UIMenuItem(Game.GetLocalizedString(apt.Name), Game.GetLocalizedString(apt.Description).Truncate)
                With item
                    Select Case config.GetValue(Of eOwner)("BUILDING", apt.Name, eOwner.Nobody)
                        Case eOwner.Nobody 'For Sale
                            .SetRightLabel($"${apt.Price.ToString("0,0")}")
                            .SetRightBadge(UIMenuItem.BadgeStyle.None)
                        Case eOwner.Michael
                            .SetRightBadge(UIMenuItem.BadgeStyle.Michael)
                        Case eOwner.Franklin
                            .SetRightBadge(UIMenuItem.BadgeStyle.Franklin)
                        Case eOwner.Trevor
                            .SetRightBadge(UIMenuItem.BadgeStyle.Trevor)
                        Case eOwner.Others
                            .SetRightBadge(UIMenuItem.BadgeStyle.Heart)
                    End Select
                    .Tag = apt
                End With
                .AddItem(item)
            Next
            .RefreshIndex()
        End With

        AptMenu = New UIMenu("", Game.GetLocalizedString("MP_PROP_GEN2A"), New Point(0, -107))
        AptMenu.SetBannerType(MenuBanner)
        AptMenu.MouseEdgeEnabled = False
        MenuPool.Add(AptMenu)
        With AptMenu
            For Each apt As ApartmentClass In Apartments
                Dim item As New UIMenuItem(Game.GetLocalizedString(apt.Name), Game.GetLocalizedString(apt.Description).Truncate)
                With item
                    Select Case config.GetValue(Of eOwner)("BUILDING", apt.Name, eOwner.Nobody)
                        Case eOwner.Nobody 'For Sale
                            .SetRightBadge(UIMenuItem.BadgeStyle.None)
                        Case eOwner.Michael
                            .SetRightBadge(UIMenuItem.BadgeStyle.Michael)
                        Case eOwner.Franklin
                            .SetRightBadge(UIMenuItem.BadgeStyle.Franklin)
                        Case eOwner.Trevor
                            .SetRightBadge(UIMenuItem.BadgeStyle.Trevor)
                        Case eOwner.Others
                            .SetRightBadge(UIMenuItem.BadgeStyle.Heart)
                    End Select
                    .Tag = apt
                End With
                .AddItem(item)
            Next
            .RefreshIndex()
        End With

        GrgMenu = New UIMenu("", Game.GetLocalizedString("MP_PROP_GEN2B"), New Point(0, -107))
        GrgMenu.SetBannerType(MenuBanner)
        GrgMenu.MouseEdgeEnabled = False
        MenuPool.Add(GrgMenu)
        With GrgMenu
            For Each apt In Apartments
                Dim item As New UIMenuItem(Game.GetLocalizedString(apt.Name), Game.GetLocalizedString(apt.Description).Truncate)
                With item
                    Select Case config.GetValue(Of eOwner)("BUILDING", apt.Name, eOwner.Nobody)
                        Case eOwner.Nobody 'For Sale
                            .SetRightBadge(UIMenuItem.BadgeStyle.None)
                        Case eOwner.Michael
                            .SetRightBadge(UIMenuItem.BadgeStyle.Michael)
                        Case eOwner.Franklin
                            .SetRightBadge(UIMenuItem.BadgeStyle.Franklin)
                        Case eOwner.Trevor
                            .SetRightBadge(UIMenuItem.BadgeStyle.Trevor)
                        Case eOwner.Others
                            .SetRightBadge(UIMenuItem.BadgeStyle.Heart)
                    End Select
                    .Tag = apt
                End With
                .AddItem(item)
            Next
            .RefreshIndex()
        End With

        For Each apt In Apartments
            apt.Load()
        Next

            SpawnForSaleSigns()
            LockDoors()
            RuntimeLoaded = True
        Catch ex As Exception
            Logger.Log($"LoadRuntime {Name}: {ex.Message} {ex.StackTrace}")
            UnloadRuntime()
        End Try
    End Sub

    ' Libera menus (do pool e de seus eventos), placa de venda e menus de cada apartamento.
    Public Sub UnloadRuntime()
        Try
            If Apartments IsNot Nothing Then
                For Each apt In Apartments : apt.Unload() : Next
            End If
            If BuyMenu IsNot Nothing Then MenuPool.Remove(BuyMenu) : BuyMenu = Nothing
            If AptMenu IsNot Nothing Then MenuPool.Remove(AptMenu) : AptMenu = Nothing
            If GrgMenu IsNot Nothing Then MenuPool.Remove(GrgMenu) : GrgMenu = Nothing
            DeleteSaleSign()
        Catch ex As Exception
            Logger.Log($"UnloadRuntime {Name}: {ex.Message} {ex.StackTrace}")
        Finally
            RuntimeLoaded = False
        End Try
    End Sub

    Private Sub DeleteSaleSign()
        If SaleSignProp IsNot Nothing Then
            If SaleSignProp.Exists() Then SaleSignProp.Delete()
            SaleSignProp = Nothing
        End If
    End Sub

    Public Sub LockDoors()
        Try
            Select Case FrontDoor
                Case eFrontDoor.DoubleDoors
                    Door1.LockDoor()
                    Door2.LockDoor()
                Case eFrontDoor.StandardDoor
                    Door1.LockDoor()
            End Select
            If GarageDoor = eFrontDoor.StandardDoor Then Door3.LockDoor()
        Catch ex As Exception
            Logger.Log($"LockDoors {Name}: {ex.Message}")
        End Try
    End Sub

    Public Sub SpawnForSaleSigns()
        If SaleSignProp IsNot Nothing AndAlso SaleSignProp.Exists() Then Return
        Try
            Dim m As Model = SaleSign.Model
            If Not m.IsInCdImage OrElse Not m.IsValid Then Return
            If Not m.Request(1500) Then Return          ' tenta de novo no proximo carregamento do predio
            SaleSignProp = World.CreateProp(m, SaleSign.Position.ToVector3, New Vector3(0F, 0F, SaleSign.Position.W), True, False)
            m.MarkAsNoLongerNeeded()
            If SaleSignProp IsNot Nothing Then SaleSignProp.IsPersistent = True
        Catch ex As Exception
            Logger.Log($"SpawnForSaleSigns {Name}: {ex.Message}")
        End Try
    End Sub

    Public Sub RefreshBuyMenu()
        If BuyMenu Is Nothing Then Return
        BuyMenu.MenuItems.Clear()
        For Each apt In Apartments
            Dim item As New UIMenuItem(Game.GetLocalizedString(apt.Name), Game.GetLocalizedString(apt.Description).Truncate)
            With item
                Select Case config.GetValue(Of eOwner)("BUILDING", apt.Name, eOwner.Nobody)
                    Case eOwner.Nobody 'For Sale
                        .SetRightLabel($"${apt.Price.ToString("0,0")}")
                        .SetRightBadge(UIMenuItem.BadgeStyle.None)
                    Case eOwner.Michael
                        .SetRightBadge(UIMenuItem.BadgeStyle.Michael)
                    Case eOwner.Franklin
                        .SetRightBadge(UIMenuItem.BadgeStyle.Franklin)
                    Case eOwner.Trevor
                        .SetRightBadge(UIMenuItem.BadgeStyle.Trevor)
                    Case eOwner.Others
                        .SetRightBadge(UIMenuItem.BadgeStyle.Heart)
                End Select
                .Tag = apt
            End With
            BuyMenu.AddItem(item)
        Next
        BuyMenu.RefreshIndex()
    End Sub

    Public Sub RefreshAptMenu()
        If AptMenu Is Nothing Then Return
        AptMenu.MenuItems.Clear()
        For Each apt In Apartments
            Dim item As New UIMenuItem(Game.GetLocalizedString(apt.Name), Game.GetLocalizedString(apt.Description).Truncate)
            With item
                Select Case config.GetValue(Of eOwner)("BUILDING", apt.Name, eOwner.Nobody)
                    Case eOwner.Nobody 'For Sale
                        .SetRightBadge(UIMenuItem.BadgeStyle.None)
                    Case eOwner.Michael
                        .SetRightBadge(UIMenuItem.BadgeStyle.Michael)
                    Case eOwner.Franklin
                        .SetRightBadge(UIMenuItem.BadgeStyle.Franklin)
                    Case eOwner.Trevor
                        .SetRightBadge(UIMenuItem.BadgeStyle.Trevor)
                    Case eOwner.Others
                        .SetRightBadge(UIMenuItem.BadgeStyle.Heart)
                End Select
                .Tag = apt
            End With
            AptMenu.AddItem(item)
        Next
        AptMenu.RefreshIndex()
    End Sub

    Public Sub RefreshGrgMenu()
        If GrgMenu Is Nothing Then Return
        GrgMenu.MenuItems.Clear()
        For Each apt In Apartments
            Dim item As New UIMenuItem(Game.GetLocalizedString(apt.Name), Game.GetLocalizedString(apt.Description).Truncate)
            With item
                Select Case config.GetValue(Of eOwner)("BUILDING", apt.Name, eOwner.Nobody)
                    Case eOwner.Nobody 'For Sale
                        .SetRightBadge(UIMenuItem.BadgeStyle.None)
                    Case eOwner.Michael
                        .SetRightBadge(UIMenuItem.BadgeStyle.Michael)
                    Case eOwner.Franklin
                        .SetRightBadge(UIMenuItem.BadgeStyle.Franklin)
                    Case eOwner.Trevor
                        .SetRightBadge(UIMenuItem.BadgeStyle.Trevor)
                    Case eOwner.Others
                        .SetRightBadge(UIMenuItem.BadgeStyle.Heart)
                End Select
                .Tag = apt
            End With
            GrgMenu.AddItem(item)
        Next
        GrgMenu.RefreshIndex()
    End Sub

    Public Function GarageDistance() As Single
        If Game.Player.Character.IsInVehicle Then
            Return Game.Player.Character.CurrentVehicle.Position.DistanceToSquared(GarageInPos)
        Else
            Return Game.Player.Character.Position.DistanceToSquared(GarageFootInPos.ToVector3)
        End If
    End Function

    Public Function EntranceDistance() As Single
        Return Game.Player.Character.Position.DistanceToSquared(BuildingInPos.ToVector3)
    End Function

    Public Function SaleSignDistance() As Single
        If EntranceDistance() <= 300.0F Then
            Return Game.Player.Character.Position.DistanceToSquared(SaleSign.Position.ToVector3)
        Else
            If SaleSignProp <> Nothing Then
                Return Game.Player.Character.Position.DistanceToSquared(SaleSignProp.Position - SaleSignProp.RightVector)
            Else
                Return Game.Player.Character.Position.DistanceToSquared(SaleSign.Position.ToVector3)
            End If
        End If
    End Function

    Public Function IsForSale() As Boolean
        Return BuildingBlip.Sprite = BlipSprite.SafehouseForSale Or BlipSprite.OfficeForSale Or BlipSprite.GarageForSale
    End Function

    Public Function GarageElevatorDistance(apt As ApartmentClass) As Single
        Return Game.Player.Character.Position.DistanceToSquared(apt.GarageElevatorPos)
    End Function

    Public Function GarageMenuDistance(apt As ApartmentClass) As Single
        Return Game.Player.Character.Position.DistanceToSquared(apt.GarageMenuPos)
    End Function

    Public Function IsAtHome() As Boolean
        Return NFunc.Call(Of Boolean)(Hash.IS_INTERIOR_SCENE)
    End Function

    Public Sub HideExterior()
        If Not HideObjects Is Nothing Then
            If IsAtHome() AndAlso HideObjects.Count <> 0 AndAlso HighEndApartment.Building Is Me Then
                NFunc.Call(BEGIN_HIDE_MAP_OBJECT_THIS_FRAME)
                For Each obj In HideObjects
                    NFunc.Call(CType(&HA97F257D0151A6ABUL, GTA.Native.Hash), obj.GetHashKey)
                Next
                NFunc.Call(DISABLE_OCCLUSION_THIS_FRAME)
            End If
        End If
    End Sub

    Public Sub RefreshBlips()
        CreateBlips()
    End Sub

    Private Sub AptMenu_OnItemSelect(sender As UIMenu, selectedItem As UIMenuItem, index As Integer) Handles AptMenu.OnItemSelect
        Try
            Dim selectedApt As ApartmentClass = selectedItem.Tag
            If debugMode Then
                Audio.PlaySoundAt(PP, "DOOR_BUZZ", "MP_PLAYER_APARTMENT")
                AptMenu.Visible = False
                HideHud = True
                PlayEnterApartmentCamera(3000, True, True, CameraShake.Hand, 0.4F)
                selectedApt.SetInteriorActive()
                PP.Position = selectedApt.ApartmentInPos
                Select Case selectedApt.ApartmentType
                    Case eApartmentType.LowEnd
                        LowEndApartment.Apartment = selectedApt
                        LowEndApartment.SpawnDoor()
                    Case eApartmentType.MediumEnd
                        MediumEndApartment.Apartment = selectedApt
                        MediumEndApartment.SpawnDoor()
                    Case eApartmentType.None, eApartmentType.IPL, eApartmentType.IPLwoStyle
                        HighEndApartment.Building = Me
                End Select
                selectedApt.PlayApartmentEnterCutscene()
                World.DestroyAllCameras()
                World.RenderingCamera = Nothing
                HideHud = False
            Else
                If selectedApt.Owner = GetPlayer() Then
                    Audio.PlaySoundAt(PP, "DOOR_BUZZ", "MP_PLAYER_APARTMENT")
                    AptMenu.Visible = False
                    HideHud = True
                    PlayEnterApartmentCamera(3000, True, True, CameraShake.Hand, 0.4F)
                    selectedApt.SetInteriorActive()
                    PP.Position = selectedApt.ApartmentInPos
                    Select Case selectedApt.ApartmentType
                        Case eApartmentType.LowEnd
                            LowEndApartment.Apartment = selectedApt
                            LowEndApartment.SpawnDoor()
                        Case eApartmentType.MediumEnd
                            MediumEndApartment.Apartment = selectedApt
                            MediumEndApartment.SpawnDoor()
                        Case eApartmentType.None, eApartmentType.IPL, eApartmentType.IPLwoStyle
                            HighEndApartment.Building = Me
                    End Select
                    selectedApt.PlayApartmentEnterCutscene()
                    World.DestroyAllCameras()
                    World.RenderingCamera = Nothing
                    HideHud = False
                End If
            End If
        Catch ex As Exception
            Logger.Log($"{ex.Message} {ex.StackTrace}")
        End Try
    End Sub

    Public Function GetGarageVehicleCount() As Integer
        Select Case GarageType
            Case eGarageType.TwoCarGarage
                Return 2
            Case eGarageType.SixCarGarage
                Return 6
            Case eGarageType.TenCarGarage
                Return 10
            Case Else
                Return 20
        End Select
    End Function

    Private Sub SaveVehicle(selectedApt As ApartmentClass)
        Try
            GrgMenu.Visible = False
            HideHud = False
            PlayEnterGarageCamera(7000, True, True, CameraShake.Hand, 0.4F)
            FadeScreen(1)
            HideHud = False
            World.DestroyAllCameras()
            World.RenderingCamera = Nothing
            Select Case GarageType
                Case eGarageType.TwoCarGarage
                    TwoCarGarage.Apartment = selectedApt
                    TwoCarGarage.Interior.SetInteriorActive

                    If PP.IsInVehicle Then
                        'In Vehicle
                        Dim currVeh = PP.CurrentVehicle
                        Dim FromApartment = currVeh.GetInt(vehIdDecor)
                        Dim UniqueID = currVeh.GetInt(vehUidDecor)

                        PP.Task.WarpOutOfVehicle(PP.CurrentVehicle)

                        If currVeh.IsCurrentVehicleExistInList Then outVehicleList.Remove(currVeh)
                        Dim uid As Integer = Guid.NewGuid.GetHashCode
                        Dim newVeh As New VehicleData($"{grgXmlPath}{selectedApt.GarageFilePath}\{uid}.xml", New VehicleClass(currVeh, GetPlayer, selectedApt.ID, uid, GetAvailableIndex(selectedApt.Vehicles, GarageType)))
                        If Not newVeh.Save() Then
                            ' nada foi apagado: o carro continua salvo na garagem de origem
                            Logger.Log($"SaveVehicle: falha ao salvar {uid}.xml")
                            ShowHelp("~r~Could not save vehicle")
                        Else
                            Select Case FromApartment
                                Case 0
                                    'Nothing need to do for this step
                                Case selectedApt.ID
                                    Dim ExistingFileToDelete As String = $"{grgXmlPath}{selectedApt.GarageFilePath}\{UniqueID}.xml"
                                    If File.Exists(ExistingFileToDelete) Then File.Delete(ExistingFileToDelete)
                                Case Else
                                    Dim ExistingFileToDelete As String = $"{grgXmlPath}{Helper.apartments.Find(Function(x) x.ID = FromApartment).GarageFilePath}\{UniqueID}.xml"
                                    If File.Exists(ExistingFileToDelete) Then File.Delete(ExistingFileToDelete)
                            End Select
                        End If
                        PP.Position = TwoCarGarage.Elevator
                        TwoCarGarage.LoadVehiclesSetPlayerPos(uid)
                        currVeh.AttachedBlip.Delete()
                        currVeh.Delete()
                        Script.Wait(1000)
                        PP.Task.LeaveVehicle(LeaveVehicleFlags.None)
                    Else
                        'On Foot
                        PP.Position = TwoCarGarage.SpawnInPos.ToVector3
                        PP.Heading = TwoCarGarage.SpawnInPos.W
                        TwoCarGarage.LoadVehicles()
                    End If

                    FadeScreen(0)
                Case eGarageType.SixCarGarage
                    SixCarGarage.Apartment = selectedApt
                    SixCarGarage.Interior.SetInteriorActive

                    If PP.IsInVehicle Then
                        'In Vehicle
                        Dim currVeh = PP.CurrentVehicle
                        Dim FromApartment = currVeh.GetInt(vehIdDecor)
                        Dim UniqueID = currVeh.GetInt(vehUidDecor)

                        PP.Task.WarpOutOfVehicle(PP.CurrentVehicle)

                        If currVeh.IsCurrentVehicleExistInList Then outVehicleList.Remove(currVeh)
                        Dim uid As Integer = Guid.NewGuid.GetHashCode
                        Dim newVeh As New VehicleData($"{grgXmlPath}{selectedApt.GarageFilePath}\{uid}.xml", New VehicleClass(currVeh, GetPlayer, selectedApt.ID, uid, GetAvailableIndex(selectedApt.Vehicles, GarageType)))
                        If Not newVeh.Save() Then
                            ' nada foi apagado: o carro continua salvo na garagem de origem
                            Logger.Log($"SaveVehicle: falha ao salvar {uid}.xml")
                            ShowHelp("~r~Could not save vehicle")
                        Else
                            Select Case FromApartment
                                Case 0
                                    'Nothing need to do for this step
                                Case selectedApt.ID
                                    Dim ExistingFileToDelete As String = $"{grgXmlPath}{selectedApt.GarageFilePath}\{UniqueID}.xml"
                                    If File.Exists(ExistingFileToDelete) Then File.Delete(ExistingFileToDelete)
                                Case Else
                                    Dim ExistingFileToDelete As String = $"{grgXmlPath}{Helper.apartments.Find(Function(x) x.ID = FromApartment).GarageFilePath}\{UniqueID}.xml"
                                    If File.Exists(ExistingFileToDelete) Then File.Delete(ExistingFileToDelete)
                            End Select
                        End If
                        PP.Position = SixCarGarage.Elevator
                        SixCarGarage.LoadVehiclesSetPlayerPos(uid)
                        currVeh.AttachedBlip.Delete()
                        currVeh.Delete()
                        Script.Wait(1000)
                        PP.Task.LeaveVehicle(LeaveVehicleFlags.None)
                    Else
                        'On Foot
                        PP.Position = SixCarGarage.SpawnInPos.ToVector3
                        PP.Heading = SixCarGarage.SpawnInPos.W
                        SixCarGarage.LoadVehicles()
                    End If

                    FadeScreen(0)
                Case eGarageType.TenCarGarage
                    TenCarGarage.Apartment = selectedApt
                    TenCarGarage.Interior.SetInteriorActive()

                    If PP.IsInVehicle Then
                        'In Vehicle
                        Dim currVeh = PP.CurrentVehicle
                        Dim FromApartment = currVeh.GetInt(vehIdDecor)
                        Dim UniqueID = currVeh.GetInt(vehUidDecor)

                        PP.Task.WarpOutOfVehicle(PP.CurrentVehicle)

                        If currVeh.IsCurrentVehicleExistInList Then outVehicleList.Remove(currVeh)
                        Dim uid As Integer = Guid.NewGuid.GetHashCode
                        Dim newVeh As New VehicleData($"{grgXmlPath}{selectedApt.GarageFilePath}\{uid}.xml", New VehicleClass(currVeh, GetPlayer, selectedApt.ID, uid, GetAvailableIndex(selectedApt.Vehicles, GarageType)))
                        If Not newVeh.Save() Then
                            ' nada foi apagado: o carro continua salvo na garagem de origem
                            Logger.Log($"SaveVehicle: falha ao salvar {uid}.xml")
                            ShowHelp("~r~Could not save vehicle")
                        Else
                            Select Case FromApartment
                                Case 0
                                    'Nothing need to do for this step
                                Case selectedApt.ID
                                    Dim ExistingFileToDelete As String = $"{grgXmlPath}{selectedApt.GarageFilePath}\{UniqueID}.xml"
                                    If File.Exists(ExistingFileToDelete) Then File.Delete(ExistingFileToDelete)
                                Case Else
                                    Dim ExistingFileToDelete As String = $"{grgXmlPath}{Helper.apartments.Find(Function(x) x.ID = FromApartment).GarageFilePath}\{UniqueID}.xml"
                                    If File.Exists(ExistingFileToDelete) Then File.Delete(ExistingFileToDelete)
                            End Select
                        End If
                        PP.Position = TenCarGarage.Elevator
                        TenCarGarage.LoadVehiclesSetPlayerPos(uid)
                        currVeh.AttachedBlip.Delete()
                        currVeh.Delete()
                        Script.Wait(1000)
                        PP.Task.LeaveVehicle(LeaveVehicleFlags.None)
                    Else
                        'On Foot
                        PP.Position = TenCarGarage.SpawnInPos.ToVector3
                        PP.Heading = TenCarGarage.SpawnInPos.W
                        TenCarGarage.LoadVehicles()
                    End If

                    FadeScreen(0)
                Case eGarageType.TwentyCarGarage
                    TwentyCarGarage.SetInteriorActive()
            End Select
        Catch ex As Exception
            Logger.Log($"SaveVehicle: {ex.Message} {ex.StackTrace}")
            ' garante que a tela, a camera e o HUD nao fiquem presos se algo falhar no meio
            Try
                World.DestroyAllCameras()
                World.RenderingCamera = Nothing
                HideHud = False
                FadeScreen(0)
            Catch
            End Try
        End Try
    End Sub

    Private Sub GrgMenu_OnItemSelect(sender As UIMenu, selectedItem As UIMenuItem, index As Integer) Handles GrgMenu.OnItemSelect
        Try
            Dim selectedApt As ApartmentClass = selectedItem.Tag
            If selectedApt.Owner = GetPlayer() Then
                If PP.IsInVehicle Then
                    If Not selectedApt.Vehicles.Count = GetGarageVehicleCount() Then
                        World.RenderingCamera = Nothing
                        World.DestroyAllCameras()
                        HideHud = False
                        SaveVehicle(selectedApt)
                    Else
                        If selectedApt.VehiclesContain(Game.Player.Character.LastVehicle) Then
                            World.RenderingCamera = Nothing
                            World.DestroyAllCameras()
                            HideHud = False
                            SaveVehicle(selectedApt)
                        Else
                            'Garage is full
                            Screen.ShowSubtitle(Game.GetLocalizedString("WEB_VEH_FULL"))
                        End If
                    End If
                Else
                    World.RenderingCamera = Nothing
                    World.DestroyAllCameras()
                    HideHud = False
                    SaveVehicle(selectedApt)
                End If
            End If
        Catch ex As Exception
            Logger.Log($"{ex.Message} {ex.StackTrace}")
        End Try
    End Sub

    Private Sub AptMenu_OnMenuClose(sender As UIMenu) Handles AptMenu.OnMenuClose, BuyMenu.OnMenuClose
        FadeScreen(1)
        World.DestroyAllCameras()
        World.RenderingCamera = Nothing
        HideHud = False
        FadeScreen(0)
    End Sub

    Private Sub BuyMenu_OnItemSelect(sender As UIMenu, selectedItem As UIMenuItem, index As Integer) Handles BuyMenu.OnItemSelect
        Try
            For Each apt In Apartments
                Dim selectedApt As ApartmentClass = selectedItem.Tag
                If selectedApt.Name = apt.Name AndAlso selectedItem.RightBadge = UIMenuItem.BadgeStyle.None AndAlso apt.Owner = eOwner.Nobody Then
                    'Buy Apartment
                    Select Case GetPlayer()
                        Case eOwner.Michael, eOwner.Franklin, eOwner.Trevor
                            If PM > apt.Price Then
                                apt.UpdateApartmentOwner()
                                BuyMenu.Visible = False
                                FadeScreen(1)
                                Player.Money = (PM - apt.Price)
                                BuildingBlip.Delete()
                                If Not GarageBlip Is Nothing Then GarageBlip.Delete()
                                RefreshBuyMenu()
                                RefreshAptMenu()
                                RefreshGrgMenu()
                                FadeScreen(0)
                                PlayPropertyPurchase(apt.Name)
                                RefreshBlips()
                                Script.Wait(2000)
                                FadeScreen(1)
                                World.DestroyAllCameras()
                                World.RenderingCamera = Nothing
                                HideHud = False
                                FadeScreen(0)
                            Else
                                Screen.ShowSubtitle(Game.GetLocalizedString("MP_REP_PROP_4"))
                            End If
                        Case Else
                            apt.UpdateApartmentOwner()
                            BuyMenu.Visible = False
                            FadeScreen(1)
                            BuildingBlip.Delete()
                            If Not GarageBlip Is Nothing Then GarageBlip.Delete()
                            RefreshBuyMenu()
                            RefreshAptMenu()
                            RefreshGrgMenu()
                            FadeScreen(0)
                            PlayPropertyPurchase(apt.Name)
                            RefreshBlips()
                            Script.Wait(2000)
                            FadeScreen(1)
                            World.DestroyAllCameras()
                            World.RenderingCamera = Nothing
                            HideHud = False
                            FadeScreen(0)
                    End Select
                End If
            Next
        Catch ex As Exception
            Logger.Log($"{ex.Message} {ex.StackTrace}")
        End Try
    End Sub

    Public Sub PlayEnterApartmentCamera(duration As Integer, easePosition As Boolean, easeRotation As Boolean, camShake As CameraShake, amplitude As Single)
        HideHud = True
        Select Case FrontDoor
            Case eFrontDoor.DoubleDoors
                Door1.UnlockDoor()
                Door2.UnlockDoor()
            Case eFrontDoor.StandardDoor
                Door1.UnlockDoor()
        End Select
        PP.Task.GoToPos(BuildingLobby.ToVector3, True, 7000)
        Dim scriptCam As Camera = World.CreateCamera(EnterCamera1.Position, EnterCamera1.Rotation, EnterCamera1.FOV)
        Dim interpCam As Camera = World.CreateCamera(EnterCamera2.Position, EnterCamera2.Rotation, EnterCamera2.FOV)
        World.RenderingCamera = scriptCam
        scriptCam.InterpTo(interpCam, duration, easePosition, easeRotation)
        World.RenderingCamera = interpCam
        interpCam.Shake(camShake, amplitude)
        Script.Wait(duration)
        Select Case FrontDoor
            Case eFrontDoor.DoubleDoors
                Door1.LockDoor()
                Door2.LockDoor()
            Case eFrontDoor.StandardDoor
                Door1.LockDoor()
        End Select
        HideHud = False
    End Sub

    Public Sub PlayExitApartmentCamera(duration As Integer, easePosition As Boolean, easeRotation As Boolean, camShake As CameraShake, amplitude As Single)
        HideHud = True
        PP.Position = BuildingLobby.ToVector3
        PP.Heading = BuildingOutPos.W
        Select Case FrontDoor
            Case eFrontDoor.DoubleDoors
                Door1.UnlockDoor()
                Door2.UnlockDoor()
            Case eFrontDoor.StandardDoor
                Door1.UnlockDoor()
        End Select
        PP.Task.GoToPos(BuildingOutPos.ToVector3, False, 7000)
        Dim scriptCam As Camera = World.CreateCamera(EnterCamera2.Position, EnterCamera2.Rotation, EnterCamera2.FOV)
        Dim interpCam As Camera = World.CreateCamera(EnterCamera1.Position, EnterCamera1.Rotation, EnterCamera1.FOV)
        World.RenderingCamera = scriptCam
        scriptCam.InterpTo(interpCam, duration, easePosition, easeRotation)
        World.RenderingCamera = interpCam
        interpCam.Shake(camShake, amplitude)
        Script.Wait(duration)
        World.DestroyAllCameras()
        World.RenderingCamera = Nothing
        Select Case FrontDoor
            Case eFrontDoor.DoubleDoors
                Door1.LockDoor()
                Door2.LockDoor()
            Case eFrontDoor.StandardDoor
                Door1.LockDoor()
        End Select
        HideHud = False
    End Sub

    Public Sub PlayEnterGarageCamera(duration As Integer, easePosition As Boolean, easeRotation As Boolean, camShake As CameraShake, amplitude As Single)
        If GarageDoor = eFrontDoor.StandardDoor Then
            HideHud = True
            Door3.UnlockDoor()

            If PP.IsInVehicle Then
                PP.CurrentVehicle.Position = GarageOutPos.ToVector3
                PP.CurrentVehicle.Heading = GarageOutPos.W - 180.0F
                PP.CurrentVehicle.PlaceOnGround()
                Dim scriptCam As Camera = World.CreateCamera(EnterCamera3.Position, EnterCamera3.Rotation, EnterCamera3.FOV)
                Dim interpCam As Camera = World.CreateCamera(EnterCamera4.Position, EnterCamera4.Rotation, EnterCamera4.FOV)
                World.RenderingCamera = scriptCam
                Script.Wait(3000)
                Dim ts As New TaskSequence()
                ts.AddTask.DriveTo(PP.CurrentVehicle, GarageInPos, 0.1F, 5.0F, DrivingStyle.Rushed)
                ts.AddTask.DriveTo(PP.CurrentVehicle, GarageFootOutPos.ToVector3, 0.1F, 5.0F, DrivingStyle.Rushed)
                ts.AddTask.DriveTo(PP.CurrentVehicle, GarageWaypoint.ToVector3, 0.1F, 5.0F, DrivingStyle.Rushed)
                PP.Task.PerformSequence(ts)
                scriptCam.InterpTo(interpCam, duration, easePosition, easeRotation)
                World.RenderingCamera = interpCam
                interpCam.Shake(camShake, amplitude)
                Script.Wait(duration)
                ts.Close()
                ts.Dispose()
            Else
                PP.Position = New Vector3(GarageInPos.X, GarageInPos.Y, GarageInPos.Z - 1.0F)
                PP.Heading = GarageOutPos.W - 180.0F
                Dim ts As New TaskSequence()
                ts.AddTask.GoToPos(GarageFootOutPos.ToVector3, False, duration)
                ts.AddTask.GoToPos(GarageWaypoint.ToVector3, False, duration)
                PP.Task.PerformSequence(ts)
                Dim scriptCam As Camera = World.CreateCamera(EnterCamera3.Position, EnterCamera3.Rotation, EnterCamera3.FOV)
                Dim interpCam As Camera = World.CreateCamera(EnterCamera4.Position, EnterCamera4.Rotation, EnterCamera4.FOV)
                World.RenderingCamera = scriptCam
                scriptCam.InterpTo(interpCam, duration, easePosition, easeRotation)
                World.RenderingCamera = interpCam
                interpCam.Shake(camShake, amplitude)
                Script.Wait(duration)
                ts.Close()
                ts.Dispose()
            End If

            Door3.LockDoor()
        Else
            Audio.PlaySoundAt(PP, "GARAGE_DOOR_SCRIPTED_CLOSE")
        End If
    End Sub

    Public Sub PlayExitGarageCamera(duration As Integer, easePosition As Boolean, easeRotation As Boolean, camShake As CameraShake, amplitude As Single)
        If GarageDoor = eFrontDoor.StandardDoor Then
            HideHud = True
            Door3.UnlockDoor()

            If PP.IsInVehicle Then
                PP.CurrentVehicle.Position = GarageWaypoint.ToVector3
                PP.CurrentVehicle.Heading = GarageWaypoint.W
                Dim ts As New TaskSequence()
                ts.AddTask.DriveTo(PP.CurrentVehicle, GarageFootOutPos.ToVector3, 0.1F, 5.0F, DrivingStyle.Rushed)
                ts.AddTask.DriveTo(PP.CurrentVehicle, GarageInPos, 0.1F, 5.0F, DrivingStyle.Rushed)
                ts.AddTask.DriveTo(PP.CurrentVehicle, GarageOutPos.ToVector3, 0.1F, 5.0F, DrivingStyle.Rushed)
                PP.Task.PerformSequence(ts)
                Dim scriptCam As Camera = World.CreateCamera(EnterCamera4.Position, EnterCamera4.Rotation, EnterCamera4.FOV)
                Dim interpCam As Camera = World.CreateCamera(EnterCamera3.Position, EnterCamera3.Rotation, EnterCamera3.FOV)
                World.RenderingCamera = scriptCam
                scriptCam.InterpTo(interpCam, duration, easePosition, easeRotation)
                World.RenderingCamera = interpCam
                interpCam.Shake(camShake, amplitude)
                FadeScreen(0)
                Script.Wait(duration)
                ts.Close()
                ts.Dispose()
            Else
                PP.Position = GarageInPos
                PP.Heading = GarageFootOutPos.W
                FadeScreen(0)
            End If
            World.DestroyAllCameras()
            World.RenderingCamera = Nothing

            Door3.LockDoor()
            HideHud = False
        End If
    End Sub

    Public Sub PlayEnterElevatorCutScene(duration As Integer)
        HideHud = True
        Select Case GarageType
            Case eGarageType.TwoCarGarage
                Dim scriptCam As Camera = World.CreateCamera(New Vector3(176.5861F, -1007.405F, -98.99998F), New Vector3(3.541232F, 0.0000001069259F, -44.71983F), 50.0F)
                World.RenderingCamera = scriptCam
                PP.Position = TwoCarGarage.Elevator
                PP.Heading = TwoCarGarage.ElevatorInside.W - 160.0F
                PP.Task.GoToPos(TwoCarGarage.ElevatorInside.ToVector3, False, duration)
            Case eGarageType.SixCarGarage
                Dim scriptCam As Camera = World.CreateCamera(New Vector3(204.9573F, -1001.148F, -98.99999F), New Vector3(1.120068F, 0.00000005337105F, -57.21745F), 50.0F)
                World.RenderingCamera = scriptCam
                PP.Position = SixCarGarage.Elevator
                PP.Heading = SixCarGarage.ElevatorInside.W - 160.0F
                PP.Task.GoToPos(SixCarGarage.ElevatorInside.ToVector3, False, duration)
            Case eGarageType.TenCarGarage
                Dim scriptCam As Camera = World.CreateCamera(New Vector3(235.6371F, -1003.728F, -98.9999F), New Vector3(2.576892F, -0.00000005341485F, -110.4919F), 50.0F)
                World.RenderingCamera = scriptCam
                PP.Position = New Vector3(237.2018F, -1004.526F, -99.9999F)
                PP.Heading = 270.0F
                PP.Task.PlayAnimation("anim@apt_trans@elevator", "elev_1")
            Case eGarageType.TwentyCarGarage
        End Select
        Script.Wait(duration)
    End Sub

    Public Sub PlayExitElevatorCutscene(duration As Integer)
        HideHud = True
        Select Case GarageType
            Case eGarageType.TwoCarGarage
                Dim scriptCam As Camera = World.CreateCamera(New Vector3(176.5861F, -1007.405F, -98.99998F), New Vector3(3.541232F, 0.0000001069259F, -44.71983F), 50.0F)
                World.RenderingCamera = scriptCam
                PP.Position = TwoCarGarage.ElevatorInside.ToVector3
                PP.Heading = TwoCarGarage.ElevatorInside.W
                PP.Task.GoToPos(New Vector3(177.9277F, -1006.376F, -99.99992F), False, duration)
            Case eGarageType.SixCarGarage
                Dim scriptCam As Camera = World.CreateCamera(New Vector3(204.9573F, -1001.148F, -98.99999F), New Vector3(1.120068F, 0.00000005337105F, -57.21745F), 50.0F)
                World.RenderingCamera = scriptCam
                PP.Position = SixCarGarage.ElevatorInside.ToVector3
                PP.Heading = SixCarGarage.ElevatorInside.W
                PP.Task.GoToPos(New Vector3(205.923F, -999.2991F, -100.0F), False, duration)
            Case eGarageType.TenCarGarage
                Dim scriptCam As Camera = World.CreateCamera(New Vector3(235.6371F, -1003.728F, -98.9999F), New Vector3(2.576892F, -0.00000005341485F, -110.4919F), 50.0F)
                World.RenderingCamera = scriptCam
                PP.Position = TenCarGarage.ElevatorInside.ToVector3
                PP.Heading = TenCarGarage.ElevatorInside.W
                PP.Task.GoToPos(New Vector3(237.2018F, -1004.526F, -99.9999F), False, duration)
            Case eGarageType.TwentyCarGarage
        End Select
        Script.Wait(duration)
    End Sub

    Private Sub GrgMenu_OnMenuClose(sender As UIMenu) Handles GrgMenu.OnMenuClose
        World.RenderingCamera = Nothing
        World.DestroyAllCameras()
        HideHud = False
    End Sub
End Class

Public Enum eGarageType
    TwoCarGarage = 2
    SixCarGarage = 6
    TenCarGarage = 10
    TwentyCarGarage = 20
End Enum

Public Enum eBuildingType
    Apartment
    Garage
    Office
    ClubHouse
    Warehouse
    NightClub
    Hangar
    Bunker
End Enum

Public Enum eFrontDoor
    NoDoor
    StandardDoor
    DoubleDoors
End Enum
