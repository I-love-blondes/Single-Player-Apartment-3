Imports GTA
Imports GTA.Math
Imports GTA.Native
Imports NFunc = GTA.Native.Function

''' <summary>
''' Ciclo de vida de interiores. O mod original chamava PIN_INTERIOR_IN_MEMORY e REQUEST_IPL sem nunca desfazer:
''' cada interior visitado ficava na memoria do jogo para sempre. Aqui cada pin/IPL e registrado e liberado
''' (UNPIN_INTERIOR / REMOVE_IPL) depois que deixa de ser necessario.
''' </summary>
Public Module InteriorService

    Private Class PinInfo
        Public Ipls As New HashSet(Of String)
        Public LastNeeded As Date = Date.UtcNow
    End Class

    Private ReadOnly Pinned As New Dictionary(Of Integer, PinInfo)
    Private _lastAcquired As Integer = 0

    ' UNPIN_INTERIOR (0x261CCE7EED010641)
    Private ReadOnly PIN_INTERIOR_IN_MEMORY As GTA.Native.Hash = CType(&H2CA429C029CCF247UL, GTA.Native.Hash)
    Private ReadOnly UNPIN_INTERIOR As GTA.Native.Hash = CType(&H261CCE7EED010641UL, GTA.Native.Hash)

    Public ReadOnly Property PinnedCount As Integer
        Get
            Return Pinned.Count
        End Get
    End Property

    ''' <summary>Pina o interior em <paramref name="coord"/> e (opcionalmente) pede o IPL. So deve ser chamado ao ENTRAR.</summary>
    Public Sub Acquire(coord As Vector3, Optional ipl As String = Nothing)
        Try
            Dim id As Integer = NFunc.Call(Of Integer)(Hash.GET_INTERIOR_AT_COORDS, coord.X, coord.Y, coord.Z)
            If id = 0 Then Return

            Dim info As PinInfo = Nothing
            If Not Pinned.TryGetValue(id, info) Then
                info = New PinInfo
                Pinned(id) = info
                NFunc.Call(PIN_INTERIOR_IN_MEMORY, id)
            End If
            NFunc.Call(Hash.SET_INTERIOR_ACTIVE, id, True)
            NFunc.Call(Hash.DISABLE_INTERIOR, id, False)

            info.LastNeeded = Date.UtcNow
            _lastAcquired = id

            If Not String.IsNullOrEmpty(ipl) Then
                info.Ipls.Add(ipl)
                NFunc.Call(Hash.REQUEST_IPL, ipl)
                WaitUntil(Function() NFunc.Call(Of Boolean)(Hash.IS_IPL_ACTIVE, ipl), SpaSettings.IplTimeoutMs, $"IPL {ipl}")
            End If

            ' Interiores agora sao liberados quando ociosos: ao reentrar, espera (com limite) o interior ficar pronto
            ' antes de teleportar o jogador, senao ele cairia no vazio.
            WaitUntil(Function() NFunc.Call(Of Boolean)(Hash.IS_INTERIOR_READY, id), SpaSettings.InteriorReadyTimeoutMs, $"interior {id}")
        Catch ex As Exception
            Logger.Log($"InteriorService.Acquire: {ex.Message} {ex.StackTrace}")
        End Try
    End Sub

    Private Sub WaitUntil(cond As Func(Of Boolean), timeoutMs As Integer, what As String)
        If cond() Then Return
        Dim deadline = Date.UtcNow.AddMilliseconds(timeoutMs)
        While Not cond()
            If Date.UtcNow > deadline Then
                Logger.Log($"Timeout ({timeoutMs} ms) esperando {what}; continuando mesmo assim")
                Return
            End If
            Script.Yield()
        End While
    End Sub

    ''' <summary>Registra um IPL pedido fora de Acquire (troca de estilo do apartamento) para ser removido junto com o interior.</summary>
    Public Sub TrackIpl(ipl As String)
        If String.IsNullOrEmpty(ipl) Then Return
        Dim id As Integer = If(PI <> 0 AndAlso Pinned.ContainsKey(PI), PI, _lastAcquired)
        Dim info As PinInfo = Nothing
        If Pinned.TryGetValue(id, info) Then info.Ipls.Add(ipl)
    End Sub

    ''' <summary>Libera pins/IPLs de interiores que nao sao mais necessarios ha mais de InteriorReleaseGraceSec.</summary>
    Public Sub ReleaseUnused(needed As HashSet(Of Integer))
        If Pinned.Count = 0 Then Return
        Dim nowUtc = Date.UtcNow
        Dim toRelease As List(Of Integer) = Nothing
        For Each kv In Pinned
            If needed.Contains(kv.Key) Then
                kv.Value.LastNeeded = nowUtc
            ElseIf (nowUtc - kv.Value.LastNeeded).TotalSeconds >= SpaSettings.InteriorReleaseGraceSec Then
                If toRelease Is Nothing Then toRelease = New List(Of Integer)
                toRelease.Add(kv.Key)
            End If
        Next
        If toRelease IsNot Nothing Then
            For Each id In toRelease : Release(id) : Next
        End If
    End Sub

    Private Sub Release(id As Integer)
        Try
            Dim info As PinInfo = Nothing
            If Not Pinned.TryGetValue(id, info) Then Return
            For Each ipl In info.Ipls
                If NFunc.Call(Of Boolean)(Hash.IS_IPL_ACTIVE, ipl) Then NFunc.Call(Hash.REMOVE_IPL, ipl)
            Next
            NFunc.Call(UNPIN_INTERIOR, id)
            Pinned.Remove(id)
            If _lastAcquired = id Then _lastAcquired = 0
        Catch ex As Exception
            Logger.Log($"InteriorService.Release: {ex.Message} {ex.StackTrace}")
            Pinned.Remove(id)
        End Try
    End Sub

    Public Sub ReleaseAll()
        For Each id In Pinned.Keys.ToList() : Release(id) : Next
    End Sub

    ''' <summary>Troca de IPL com limite de espera (o original podia travar o jogo num While infinito).</summary>
    Public Function SwapIpl(old As String, [new] As String) As Boolean
        Try
            If Not String.IsNullOrEmpty(old) AndAlso NFunc.Call(Of Boolean)(Hash.IS_IPL_ACTIVE, old) Then NFunc.Call(Hash.REMOVE_IPL, old)
            If String.IsNullOrEmpty([new]) Then Return True
            Dim deadline = Date.UtcNow.AddMilliseconds(SpaSettings.IplTimeoutMs)
            While Not NFunc.Call(Of Boolean)(Hash.IS_IPL_ACTIVE, [new])
                NFunc.Call(Hash.REQUEST_IPL, [new])
                If Date.UtcNow > deadline Then
                    Logger.Log($"IPL '{[new]}' nao ficou ativo em {SpaSettings.IplTimeoutMs} ms")
                    Return False
                End If
                Script.Yield()
            End While
            TrackIpl([new])
            Return True
        Catch ex As Exception
            Logger.Log($"InteriorService.SwapIpl: {ex.Message} {ex.StackTrace}")
            Return False
        End Try
    End Function

End Module
