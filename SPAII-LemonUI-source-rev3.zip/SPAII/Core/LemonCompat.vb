Imports System.Drawing
Imports System.Runtime.CompilerServices
Imports GTA
Imports LemonUI
Imports LemonUI.Elements
Imports LemonUI.Menus
Imports LemonUI.Scaleform

Namespace Compat

    ''' <summary>Ponte fina SPA II -> LemonUI. Toda renderizacao/entrada e do LemonUI (SHVDN3).</summary>
    Public Class UIMenuItem
        Friend ReadOnly Native As NativeItem
        Public Tag As Object
        Friend BoundMenu As UIMenu

        Public Enum BadgeStyle
            None
            Clothes
            Franklin
            Heart
            Michael
            Tick
            Trevor
        End Enum

        Public Sub New(text As String, Optional desc As String = Nothing)
            Native = New NativeItem(If(text, ""), If(desc, ""))
            Native.Tag = Me
        End Sub

        Public Property Text As String
            Get
                Return Native.Title
            End Get
            Set(value As String)
                Native.Title = If(value, "")
            End Set
        End Property

        Public Property Description As String
            Get
                Return Native.Description
            End Get
            Set(value As String)
                Native.Description = If(value, "")
            End Set
        End Property

        Public Property Enabled As Boolean
            Get
                Return Native.Enabled
            End Get
            Set(value As Boolean)
                Native.Enabled = value
            End Set
        End Property

        Private _badge As BadgeStyle = BadgeStyle.None
        Public ReadOnly Property RightBadge As BadgeStyle
            Get
                Return _badge
            End Get
        End Property

        Public Sub SetRightLabel(label As String)
            Native.AltTitle = If(label, "")
        End Sub

        Public Sub SetRightBadge(badge As BadgeStyle)
            _badge = badge
            Native.RightBadgeSet = BadgeFor(badge)
        End Sub

        Private Shared Function BadgeFor(b As BadgeStyle) As BadgeSet
            Select Case b
                Case BadgeStyle.Tick : Return New BadgeSet("commonmenu", "shop_tick_icon", "shop_tick_icon")
                Case BadgeStyle.Clothes : Return New BadgeSet("commonmenu", "shop_clothing_icon_a", "shop_clothing_icon_b")
                Case BadgeStyle.Franklin : Return New BadgeSet("commonmenu", "shop_franklin_icon_a", "shop_franklin_icon_b")
                Case BadgeStyle.Michael : Return New BadgeSet("commonmenu", "shop_michael_icon_a", "shop_michael_icon_b")
                Case BadgeStyle.Trevor : Return New BadgeSet("commonmenu", "shop_trevor_icon_a", "shop_trevor_icon_b")
                Case BadgeStyle.Heart : Return New BadgeSet("commonmenu", "shop_heart_icon_a", "shop_heart_icon_b")
                Case Else : Return Nothing
            End Select
        End Function
    End Class

    Public Class UIMenuItemList
        Inherits List(Of UIMenuItem)
        Friend Owner As UIMenu
        Public Shadows Sub Clear()
            MyBase.Clear()
            Owner.Native.Clear()
        End Sub
    End Class

    ''' <summary>Substitutos minimos dos antigos Sprite/UIResRectangle usados como banner.</summary>
    Public Class BannerSprite
        Public Dict As String, Name As String
        Public Sub New(dict As String, name As String, pos As Object, size As Object)
            Me.Dict = dict : Me.Name = name
        End Sub
    End Class

    Public Class UIResRectangle
        Public Sub New(pos As Point, size As Size, col As Color)
        End Sub
    End Class

    Public Class UIMenu
        Friend ReadOnly Native As NativeMenu
        Public ReadOnly MenuItems As New UIMenuItemList
        Public ParentMenu As UIMenu
        Public MouseEdgeEnabled As Boolean
        Private _programmatic As Boolean
        Private _lastIndex As Integer = -1
        Private _disposed As Boolean

        Public Event OnItemSelect(sender As UIMenu, selectedItem As UIMenuItem, index As Integer)
        Public Event OnIndexChange(sender As UIMenu, newIndex As Integer)
        Public Event OnMenuClose(sender As UIMenu)

        Public Sub New(title As String, subtitle As String, Optional offset As Point = Nothing)
            Native = New NativeMenu("", If(subtitle, ""), "")
            Native.Banner = Nothing   ' o mod sempre escondeu o banner
            MenuItems.Owner = Me
            AddHandler Native.ItemActivated, AddressOf OnActivated
            AddHandler Native.SelectedIndexChanged, AddressOf OnSelected
            AddHandler Native.Opening, AddressOf OnOpening
            AddHandler Native.Closed, AddressOf OnClosed
        End Sub

        Public Property Subtitle As String
            Get
                Return Native.Name
            End Get
            Set(value As String)
                Native.Name = If(value, "")
            End Set
        End Property

        Public Sub SetBannerType(banner As Object)
            Dim s = TryCast(banner, BannerSprite)
            If s IsNot Nothing Then
                Native.Banner = New ScaledTexture(PointF.Empty, New SizeF(0, 108), s.Dict, s.Name)
            Else
                Native.Banner = Nothing
            End If
        End Sub

        Public Property Visible As Boolean
            Get
                Return Native.Visible
            End Get
            Set(value As Boolean)
                _programmatic = True
                Try
                    Native.Visible = value
                Finally
                    _programmatic = False
                End Try
            End Set
        End Property

        Public Sub AddItem(item As UIMenuItem)
            MenuItems.Add(item)
            Native.Add(item.Native)
        End Sub

        Public Sub RefreshIndex()
            If Native.Items.Count > 0 Then Native.SelectedIndex = 0
        End Sub

        Public ReadOnly Property CurrentSelection As Integer
            Get
                Return Native.SelectedIndex
            End Get
        End Property

        Public Sub BindMenuToItem(child As UIMenu, item As UIMenuItem)
            child.ParentMenu = Me
            item.BoundMenu = child
        End Sub

        Public Sub GoBack()
            Visible = False
            If ParentMenu IsNot Nothing Then ParentMenu.Visible = True
        End Sub

        Private Sub OnOpening(sender As Object, e As System.ComponentModel.CancelEventArgs)
            _lastIndex = Native.SelectedIndex ' evita OnIndexChange espurio ao abrir
        End Sub

        Private Sub OnSelected(sender As Object, e As SelectedEventArgs)
            If e.Index = _lastIndex Then Return
            _lastIndex = e.Index
            If e.Index >= 0 AndAlso e.Index < MenuItems.Count Then RaiseEvent OnIndexChange(Me, e.Index)
        End Sub

        Private Sub OnActivated(sender As Object, e As ItemActivatedArgs)
            Dim item = TryCast(e.Item.Tag, UIMenuItem)
            If item Is Nothing Then Return
            RaiseEvent OnItemSelect(Me, item, Native.Items.IndexOf(e.Item))
            If item.BoundMenu IsNot Nothing AndAlso MenuItems.Contains(item) Then
                Visible = False
                item.BoundMenu.Visible = True
            End If
        End Sub

        Private Sub OnClosed(sender As Object, e As EventArgs)
            If _programmatic OrElse _disposed Then Return   ' so o botao Voltar do jogador dispara OnMenuClose
            RaiseEvent OnMenuClose(Me)
            If ParentMenu IsNot Nothing Then ParentMenu.Visible = True
        End Sub

        Friend Sub Detach()
            _disposed = True
            RemoveHandler Native.ItemActivated, AddressOf OnActivated
            RemoveHandler Native.SelectedIndexChanged, AddressOf OnSelected
            RemoveHandler Native.Opening, AddressOf OnOpening
            RemoveHandler Native.Closed, AddressOf OnClosed
            If Native.Visible Then Visible = False
            MenuItems.Clear()
        End Sub
    End Class

    Public Class MenuPool
        Private ReadOnly _pool As New ObjectPool
        Private ReadOnly _menus As New List(Of UIMenu)

        Public Sub Add(menu As UIMenu)
            If _menus.Contains(menu) Then Return
            _menus.Add(menu)
            _pool.Add(menu.Native)
        End Sub

        ''' <summary>Remove do pool e solta eventos/itens: o menu passa a ser coletavel pelo GC.</summary>
        Public Sub Remove(menu As UIMenu)
            If menu Is Nothing Then Return
            _menus.Remove(menu)
            _pool.Remove(menu.Native)
            menu.Detach()
        End Sub

        Public Function IsAnyMenuOpen() As Boolean
            Return _pool.AreAnyVisible
        End Function

        Public Sub ProcessMenus()
            _pool.Process()
        End Sub

        Public ReadOnly Property Count As Integer
            Get
                Return _menus.Count
            End Get
        End Property
    End Class

    Public Class UIResText
        Private ReadOnly _t As ScaledText
        Public Position As Point
        Public Enum Alignment
            Left
            Centered
            Right
        End Enum
        Public Sub New(text As String, pos As Point, scale As Single, col As Color, font As GTA.UI.Font, align As Alignment)
            Position = pos
            _t = New ScaledText(New PointF(pos.X, pos.Y), text, scale, font)
            _t.Color = col
        End Sub
        Public Sub Draw()
            _t.Position = New PointF(Position.X, Position.Y)
            _t.Draw()
        End Sub
    End Class

    ''' <summary>Mensagem "propriedade comprada" via LemonUI.BigMessage, desenhada pelo tick principal.</summary>
    Public Module BigMessages
        Private _msg As BigMessage
        Private _until As Date

        Public Sub ShowPurchased(title As String, text As String)
            _msg = New BigMessage(title, text, MessageType.Weapon)
            _until = Date.UtcNow.AddSeconds(4)
        End Sub

        Public Sub Process()
            If _msg Is Nothing Then Return
            If Date.UtcNow > _until Then
                _msg = Nothing
                Return
            End If
            _msg.Update()
            _msg.DrawFullScreen()
        End Sub
    End Module

End Namespace
