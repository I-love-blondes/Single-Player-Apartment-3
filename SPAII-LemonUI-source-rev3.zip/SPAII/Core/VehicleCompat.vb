Imports System.Drawing
Imports System.Runtime.CompilerServices
Imports GTA
Imports GTA.Native

Namespace Compat

    ''' <summary>Indices nativos de SET_VEHICLE_MOD (mesmos valores do SHVDN2).</summary>
    Public Enum ModType
        Spoilers = 0
        FrontBumper = 1
        RearBumper = 2
        SideSkirt = 3
        Exhaust = 4
        Frame = 5
        Grille = 6
        Hood = 7
        Fender = 8
        RightFender = 9
        Roof = 10
        Engine = 11
        Brakes = 12
        Transmission = 13
        Horns = 14
        Suspension = 15
        Armor = 16
        FrontWheels = 23
        BackWheels = 24
        PlateHolder = 25
        VanityPlates = 26
        TrimDesign = 27
        Ornaments = 28
        Dashboard = 29
        DialDesign = 30
        DoorSpeakers = 31
        Seats = 32
        SteeringWheels = 33
        ColumnShifterLevers = 34
        Plaques = 35
        Speakers = 36
        Trunk = 37
        Hydraulics = 38
        EngineBlock = 39
        AirFilter = 40
        Struts = 41
        ArchCover = 42
        Aerials = 43
        Trim = 44
        Tank = 45
        Windows = 46
        Livery = 48
    End Enum

    Public Enum ToggleModType
        Turbo = 18
        TireSmoke = 20
        XenonHeadlights = 22
    End Enum

    Public Module VehicleCompat

        <Extension>
        Public Function GetMod(v As Vehicle, t As ModType) As Integer
            Return Native.Function.Call(Of Integer)(Hash.GET_VEHICLE_MOD, v.Handle, CInt(t))
        End Function

        <Extension>
        Public Sub SetMod(v As Vehicle, t As ModType, index As Integer, Optional variations As Boolean = False)
            Native.Function.Call(Hash.SET_VEHICLE_MOD, v.Handle, CInt(t), index, variations)
        End Sub

        <Extension>
        Public Sub ToggleMod(v As Vehicle, t As ToggleModType, toggle As Boolean)
            Native.Function.Call(Hash.TOGGLE_VEHICLE_MOD, v.Handle, CInt(t), toggle)
        End Sub

        <Extension>
        Public Function IsToggleModOn(v As Vehicle, t As ToggleModType) As Boolean
            Return Native.Function.Call(Of Boolean)(Hash.IS_TOGGLE_MOD_ON, v.Handle, CInt(t))
        End Function

        <Extension>
        Public Sub InstallModKit(v As Vehicle)
            v.Mods.InstallModKit()
        End Sub

        <Extension>
        Public Function IsNeonLightsOn(v As Vehicle, l As VehicleNeonLight) As Boolean
            Return v.Mods.IsNeonLightsOn(l)
        End Function

        <Extension>
        Public Sub SetNeonLightsOn(v As Vehicle, l As VehicleNeonLight, state As Boolean)
            v.Mods.SetNeonLightsOn(l, state)
        End Sub

        ' ---- propriedades do SHVDN2 que agora vivem em Vehicle.Mods (Get_/Set_ viram chamadas por regex) ----
        <Extension> Public Function Get_PrimaryColor(v As Vehicle) As Integer
            Return CInt(v.Mods.PrimaryColor)
        End Function
        <Extension> Public Sub Set_PrimaryColor(v As Vehicle, c As Integer)
            v.Mods.PrimaryColor = CType(c, VehicleColor)
        End Sub
        <Extension> Public Function Get_SecondaryColor(v As Vehicle) As Integer
            Return CInt(v.Mods.SecondaryColor)
        End Function
        <Extension> Public Sub Set_SecondaryColor(v As Vehicle, c As Integer)
            v.Mods.SecondaryColor = CType(c, VehicleColor)
        End Sub
        <Extension> Public Function Get_PearlescentColor(v As Vehicle) As Integer
            Return CInt(v.Mods.PearlescentColor)
        End Function
        <Extension> Public Sub Set_PearlescentColor(v As Vehicle, c As Integer)
            v.Mods.PearlescentColor = CType(c, VehicleColor)
        End Sub
        <Extension> Public Function Get_RimColor(v As Vehicle) As Integer
            Return CInt(v.Mods.RimColor)
        End Function
        <Extension> Public Sub Set_RimColor(v As Vehicle, c As Integer)
            v.Mods.RimColor = CType(c, VehicleColor)
        End Sub
        <Extension> Public Function Get_TrimColor(v As Vehicle) As Integer
            Return CInt(v.Mods.TrimColor)
        End Function
        <Extension> Public Sub Set_TrimColor(v As Vehicle, c As Integer)
            v.Mods.TrimColor = CType(c, VehicleColor)
        End Sub
        <Extension> Public Function Get_DashboardColor(v As Vehicle) As Integer
            Return CInt(v.Mods.DashboardColor)
        End Function
        <Extension> Public Sub Set_DashboardColor(v As Vehicle, c As Integer)
            v.Mods.DashboardColor = CType(c, VehicleColor)
        End Sub
        <Extension> Public Function Get_WindowTint(v As Vehicle) As Integer
            Return CInt(v.Mods.WindowTint)
        End Function
        <Extension> Public Sub Set_WindowTint(v As Vehicle, t As Integer)
            v.Mods.WindowTint = CType(t, VehicleWindowTint)
        End Sub
        <Extension> Public Function Get_WheelType(v As Vehicle) As Integer
            Return CInt(v.Mods.WheelType)
        End Function
        <Extension> Public Sub Set_WheelType(v As Vehicle, t As Integer)
            v.Mods.WheelType = CType(t, VehicleWheelType)
        End Sub
        <Extension> Public Function Get_NumberPlate(v As Vehicle) As String
            Return v.Mods.LicensePlate
        End Function
        <Extension> Public Sub Set_NumberPlate(v As Vehicle, s As String)
            If s IsNot Nothing Then v.Mods.LicensePlate = s
        End Sub
        <Extension> Public Function Get_NumberPlateType(v As Vehicle) As Integer
            Return CInt(v.Mods.LicensePlateStyle)
        End Function
        <Extension> Public Sub Set_NumberPlateType(v As Vehicle, t As Integer)
            v.Mods.LicensePlateStyle = CType(t, LicensePlateStyle)
        End Sub
        <Extension> Public Function Get_Livery(v As Vehicle) As Integer
            Return v.Mods.Livery
        End Function
        <Extension> Public Sub Set_Livery(v As Vehicle, i As Integer)
            v.Mods.Livery = i
        End Sub
        <Extension> Public Function Get_NeonLightsColor(v As Vehicle) As Color
            Return v.Mods.NeonLightsColor
        End Function
        <Extension> Public Sub Set_NeonLightsColor(v As Vehicle, c As Color)
            v.Mods.NeonLightsColor = c
        End Sub
        <Extension> Public Function Get_TireSmokeColor(v As Vehicle) As Color
            Return v.Mods.TireSmokeColor
        End Function
        <Extension> Public Sub Set_TireSmokeColor(v As Vehicle, c As Color)
            v.Mods.TireSmokeColor = c
        End Sub
        <Extension> Public Function Get_CustomPrimaryColor(v As Vehicle) As Color
            Return v.Mods.CustomPrimaryColor
        End Function
        <Extension> Public Sub Set_CustomPrimaryColor(v As Vehicle, c As Color)
            v.Mods.CustomPrimaryColor = c
        End Sub
        <Extension> Public Function Get_CustomSecondaryColor(v As Vehicle) As Color
            Return v.Mods.CustomSecondaryColor
        End Function
        <Extension> Public Sub Set_CustomSecondaryColor(v As Vehicle, c As Color)
            v.Mods.CustomSecondaryColor = c
        End Sub
        <Extension> Public Function Get_IsPrimaryColorCustom(v As Vehicle) As Boolean
            Return v.Mods.IsPrimaryColorCustom
        End Function
        <Extension> Public Function Get_IsSecondaryColorCustom(v As Vehicle) As Boolean
            Return v.Mods.IsSecondaryColorCustom
        End Function
    End Module
End Namespace

Namespace Compat
    Public Module PedCompat
        ''' <summary>Vehicle.LocalizedName do SHVDN3 (antigo FriendlyName).</summary>
        <System.Runtime.CompilerServices.Extension>
        Public Function FriendlyName(v As GTA.Vehicle) As String
            Return v.LocalizedName
        End Function

        Private ReadOnly PedField As System.Reflection.FieldInfo =
            GetType(GTA.TaskInvoker).GetField("_ped", System.Reflection.BindingFlags.NonPublic Or System.Reflection.BindingFlags.Instance)

        ''' <summary>Equivalente do antigo Task.GoTo(pos, ignorePaths, timeout). Funciona tambem dentro de TaskSequence (handle 0).</summary>
        <System.Runtime.CompilerServices.Extension>
        Public Sub GoToPos(t As GTA.TaskInvoker, pos As GTA.Math.Vector3, ignorePaths As Boolean, timeout As Integer)
            Dim handle As Integer = -1
            Try
                If PedField IsNot Nothing Then
                    Dim p = TryCast(PedField.GetValue(t), GTA.Ped)
                    If p IsNot Nothing Then handle = p.Handle
                End If
            Catch
            End Try
            If handle < 0 Then
                t.GoTo(pos, timeout)   ' fallback: navmesh
            ElseIf ignorePaths Then
                Native.Function.Call(Hash.TASK_GO_STRAIGHT_TO_COORD, handle, pos.X, pos.Y, pos.Z, 1.0F, timeout, 0.0F, 0.0F)
            Else
                Native.Function.Call(Hash.TASK_FOLLOW_NAV_MESH_TO_COORD, handle, pos.X, pos.Y, pos.Z, 1.0F, timeout, 0.0F, 0, 0.0F)
            End If
        End Sub
    End Module
End Namespace
