Imports GTA
Imports GTA.Native
Imports NFunc = GTA.Native.Function
Imports SPAII.Compat

''' <summary>
''' Limpeza periodica: remove referencias a entidades que nao existem mais, libera scaleforms e interiores
''' ociosos e coleta o lixo gerenciado. O GC sozinho NAO libera recursos nativos do jogo (pins, IPLs,
''' scaleforms, blips): por isso eles sao liberados explicitamente aqui e no descarregamento por distancia.
''' </summary>
Public Module Janitor

    Private _lastGc As Date = Date.UtcNow
    Public LastStats As String = ""

    Public Sub Run()
        Try
            PruneOutVehicles()
            VehicleTags.Purge()

            InteriorService.ReleaseUnused(ApartmentManager.NeededInteriors())
            If Not IsInGarageInterior() Then ReleaseStatScaleforms()
            If Not IsInPropInterior() Then ReleaseInstructionalButtons()

            CollectGarbageIfNeeded()
        Catch ex As Exception
            Logger.Log($"Janitor.Run: {ex.Message} {ex.StackTrace}")
        End Try
    End Sub

    ''' <summary>Tira da lista os veiculos que foram deletados/despawnados pelo jogo (e seus blips).</summary>
    Private Sub PruneOutVehicles()
        For i As Integer = outVehicleList.Count - 1 To 0 Step -1
            Dim v As Vehicle = outVehicleList(i)
            If v Is Nothing OrElse Not v.Exists() Then outVehicleList.RemoveAt(i)
        Next
    End Sub

    Private Function IsInGarageInterior() As Boolean
        Select Case PI
            Case 0 : Return False
            Case TenCarGarage.Interior.GetInterior, SixCarGarage.Interior.GetInterior, TwoCarGarage.Interior.GetInterior : Return True
        End Select
        Return False
    End Function

    Private Function IsInPropInterior() As Boolean
        Select Case PI
            Case 0 : Return False
            Case TenCarGarage.Interior.GetInterior, SixCarGarage.Interior.GetInterior, TwoCarGarage.Interior.GetInterior, LowEndApartment.Interior.GetInterior, MediumEndApartment.Interior.GetInterior : Return True
        End Select
        Return False
    End Function

    Public Sub ReleaseScaleforms()
        ReleaseStatScaleforms()
        ReleaseInstructionalButtons()
    End Sub

    Private Sub CollectGarbageIfNeeded()
        If MenuPool.IsAnyMenuOpen() Then Return
        Dim managedMB As Long = GC.GetTotalMemory(False) \ (1024 * 1024)
        Dim due As Boolean = SpaSettings.ForceGcMinutes > 0 AndAlso (Date.UtcNow - _lastGc).TotalMinutes >= SpaSettings.ForceGcMinutes
        If managedMB >= SpaSettings.GcThresholdMB OrElse due Then
            GC.Collect(2, GCCollectionMode.Optimized, False)
            _lastGc = Date.UtcNow
        End If
        LastStats = $"heap {managedMB} MB | loaded {ApartmentManager.Loaded.Count}/{buildings.Count} | pins {InteriorService.PinnedCount} | menus {MenuPool.Count} | tags {VehicleTags.Count} | outVeh {outVehicleList.Count}"
        If DebugMode Then Logger.Log("Janitor: " & LastStats)
    End Sub

End Module
