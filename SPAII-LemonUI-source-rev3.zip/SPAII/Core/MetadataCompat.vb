Imports System.Runtime.CompilerServices
Imports GTA
Imports GTA.Native

Namespace Compat

    Public Class Decor
        Public Enum eDecorType
            [Float] = 1
            [Bool] = 2
            [Int] = 3
        End Enum
        Public Shared Sub Unlock()
        End Sub
        Public Shared Sub Lock()
        End Sub
        Public Shared Sub Register(name As String, t As eDecorType)
        End Sub
        ''' <summary>Consulta nativa (usada so para detectar o mod de nitro de terceiros).</summary>
        Public Shared Function Registered(name As String, t As eDecorType) As Boolean
            Try
                Return Native.Function.Call(Of Boolean)(Hash.DECOR_IS_REGISTERED_AS_TYPE, name, CInt(t))
            Catch
                Return False
            End Try
        End Function
    End Class

    ''' <summary>
    ''' IDs de garagem dos veiculos ficam num dicionario gerenciado (handle -> ids) em vez de decorators.
    ''' Decorators exigiam destravar a tabela do jogo via memoria (Metadata.dll) e sao frageis entre builds.
    ''' </summary>
    Public Module VehicleTags
        Private ReadOnly Store As New Dictionary(Of Integer, Integer())

        Private Function SlotOf(name As String) As Integer
            If name = Helper.vehIdDecor Then Return 0
            If name = Helper.vehUidDecor Then Return 1
            Return -1
        End Function

        <Extension>
        Public Function GetInt(e As Entity, name As String) As Integer
            Dim s = SlotOf(name)
            If s >= 0 Then
                Dim v As Integer() = Nothing
                If e IsNot Nothing AndAlso Store.TryGetValue(e.Handle, v) Then Return v(s)
                Return 0
            End If
            Try
                If Native.Function.Call(Of Boolean)(Hash.DECOR_EXIST_ON, e.Handle, name) Then Return Native.Function.Call(Of Integer)(Hash.DECOR_GET_INT, e.Handle, name)
            Catch
            End Try
            Return 0
        End Function

        <Extension>
        Public Sub SetInt(e As Entity, name As String, value As Integer)
            Dim s = SlotOf(name)
            If s >= 0 Then
                Dim v As Integer() = Nothing
                If Not Store.TryGetValue(e.Handle, v) Then
                    v = New Integer(1) {}
                    Store(e.Handle) = v
                End If
                v(s) = value
                Return
            End If
            Try
                If Decor.Registered(name, Decor.eDecorType.Int) Then Native.Function.Call(Hash.DECOR_SET_INT, e.Handle, name, value)
            Catch
            End Try
        End Sub

        ''' <summary>Remove handles de entidades que nao existem mais (evita crescer e reaproveitar handle errado).</summary>
        Public Function Purge() As Integer
            Dim dead As New List(Of Integer)
            For Each h In Store.Keys
                If Not Native.Function.Call(Of Boolean)(Hash.DOES_ENTITY_EXIST, h) Then dead.Add(h)
            Next
            For Each h In dead : Store.Remove(h) : Next
            Return dead.Count
        End Function

        Public ReadOnly Property Count As Integer
            Get
                Return Store.Count
            End Get
        End Property
    End Module

    Public Module NewFunc
        Public Function IsCheating(cheat As String) As Boolean
            Return Game.WasCheatStringJustEntered(cheat)
        End Function
    End Module

End Namespace
