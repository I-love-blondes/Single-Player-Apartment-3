Imports System.IO

''' <summary>
''' Log em arquivo que nunca derruba o script: engole erros de IO, limita repeticoes
''' (uma excecao em loop de tick nao pode virar milhares de escritas por segundo) e limita o tamanho do arquivo.
''' </summary>
Public NotInheritable Class Logger

    Private Shared ReadOnly Recent As New Dictionary(Of String, Date)
    Private Shared _lastPrune As Date = Date.UtcNow
    Private Const MaxBytes As Long = 2 * 1024 * 1024

    Private Sub New()
    End Sub

    Public Shared Sub Log(message As Object)
        Try
            Dim text As String = If(message Is Nothing, "", message.ToString())
            Dim key As String = If(text.Length > 200, text.Substring(0, 200), text)
            Dim nowUtc = Date.UtcNow

            Dim last As Date
            If Recent.TryGetValue(key, last) AndAlso (nowUtc - last).TotalSeconds < 10 Then Return
            Recent(key) = nowUtc
            If Recent.Count > 200 OrElse (nowUtc - _lastPrune).TotalMinutes > 5 Then
                Recent.Clear()
                _lastPrune = nowUtc
            End If

            Dim path As String = ".\SPA II.log"
            If File.Exists(path) AndAlso New FileInfo(path).Length > MaxBytes Then File.Delete(path)
            File.AppendAllText(path, DateTime.Now & ":" & text & Environment.NewLine)
        Catch
            ' log nunca pode causar excecao
        End Try
    End Sub

    Public Shared Sub Logg(message As Object)
        Try
            File.AppendAllText(".\SPA II.txt", message & Environment.NewLine)
        Catch
        End Try
    End Sub

End Class
