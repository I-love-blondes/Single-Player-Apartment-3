Imports System.Drawing
Imports System.IO
Imports System.Threading
Imports System.Windows.Forms
Imports GTA
Imports GTA.Math
Imports GTA.Native
Imports iFruitAddon2
Imports SPAII.Compat
Imports GameControl = GTA.Control
Imports NFunc = GTA.Native.Function

Public Class SPA2
    Inherits Script

    Private _firstTickLogged As Boolean = False

    ' Cada etapa de inicializacao e independente: uma falha (ex.: pasta ausente, telefone, guarda-roupa)
    ' e registrada no log e NAO impede o script de iniciar nem de criar os blips das propriedades.
    Private Sub RunStep(name As String, action As Action)
        Try
            action()
        Catch ex As Exception
            Logger.Log($"[STARTUP] etapa '{name}' falhou: {ex.GetType().Name}: {ex.Message}{vbNewLine}{ex.StackTrace}")
        End Try
    End Sub

    Private Shared Sub EnsureFolders()
        IO.Directory.CreateDirectory("scripts\SPA II")
        IO.Directory.CreateDirectory("scripts\SPA II\Garages")
        IO.Directory.CreateDirectory("scripts\SPA II\Sounds")
    End Sub

    Public Sub New()
        RunStep("EnsureFolders", AddressOf EnsureFolders)
        RunStep("GenerateModConfig", AddressOf GenerateModConfig)
        RunStep("LoadModConfig", AddressOf LoadModConfig)
        RunStep("Settings", Sub() SpaSettings.Load(config))
        RunStep("LoadBuildings", AddressOf LoadBuildings)
        RunStep("LoadContacts", AddressOf LoadContacts)
        RunStep("LoadWardrobe", AddressOf LoadWardrobe)
        RunStep("GarageMenu2", AddressOf TwoCarGarage.LoadGarageMenu)
        RunStep("GarageMenu6", AddressOf SixCarGarage.LoadGarageMenu)
        RunStep("GarageMenu10", AddressOf TenCarGarage.LoadGarageMenu)
        RunStep("LoadDebugMenu", AddressOf LoadDebugMenu)
        RunStep("EnableOnlineMap", AddressOf EnableOnlineMap)

        Dim blipCount As Integer = 0
        Try
            For Each bd In buildings
                If bd.BuildingBlip IsNot Nothing Then blipCount += 1
            Next
        Catch
        End Try
        Dim ver As String = "?"
        Try
            ver = Game.Version.ToString()
        Catch
        End Try
        Logger.Log($"[STARTUP] SPA II iniciado | jogo {ver} | predios {buildings.Count} | blips {blipCount} | buildingsLoaded={buildingsLoaded}")
    End Sub

    Private Sub SPA2_Tick(sender As Object, e As EventArgs) Handles Me.Tick
        PP = Game.Player.Character
        LV = Game.Player.Character.LastVehicle
        PM = Game.Player.Money
        Player = Game.Player
        PI = Game.Player.Character.Position.GetInterior

        If Not _firstTickLogged Then
            _firstTickLogged = True
            Logger.Log("[STARTUP] primeiro tick executado: o script esta rodando")
        End If

        Try
            'Decide quais predios carregar/descarregar (a cada SweepIntervalMs) e roda a limpeza periodica
            ApartmentManager.Update()

            If buildingsLoaded Then
                'So predios carregados (poucos, perto do jogador) entram no loop por frame
                Dim nearby As List(Of BuildingClass) = ApartmentManager.Loaded
                For i As Integer = 0 To nearby.Count - 1
                    Dim bd As BuildingClass = nearby(i)
                    If Not bd.RuntimeLoaded Then Continue For

                    'Open Buy Menu
                    If bd.SaleSignDistance <= 3.0F Then
                        If Not MenuPool.IsAnyMenuOpen() AndAlso Not PP.IsInVehicle Then
                            Select Case bd.BuildingType
                                Case eBuildingType.Apartment, eBuildingType.ClubHouse
                                    ShowHelp(Game.GetLocalizedString("MP_PROP_PUR0"))
                                Case eBuildingType.Garage, eBuildingType.Hangar
                                    ShowHelp(Game.GetLocalizedString("MP_PROP_PUR1"))
                                Case eBuildingType.Office, eBuildingType.Bunker, eBuildingType.NightClub, eBuildingType.Warehouse
                                    ShowHelp(Game.GetLocalizedString("MP_PROP_OFF_BUY"))
                            End Select
                            If Game.IsControlJustReleased(GameControl.Context) Then
                                FadeScreen(1)
                                bd.BuyMenu.Visible = True
                                World.RenderingCamera = World.CreateCamera(bd.CameraPos.Position, bd.CameraPos.Rotation, bd.CameraPos.FOV)
                                HideHud = True
                                FadeScreen(0)
                            End If
                        End If
                    End If

                    'Open Apartment Menu
                    If bd.EntranceDistance <= 2.0F Then
                        If Not MenuPool.IsAnyMenuOpen() AndAlso Not PP.IsInVehicle Then
                            Select Case bd.BuildingType
                                Case eBuildingType.Apartment
                                    ShowHelp(Game.GetLocalizedString("MP_PROP_BUZZ1"))
                                Case eBuildingType.ClubHouse
                                    ShowHelp(Game.GetLocalizedString("MP_BUZZ_CLU"))
                                Case eBuildingType.Office
                                    ShowHelp(Game.GetLocalizedString("MP_BUZZ_OFF"))
                            End Select
                            If Game.IsControlJustReleased(GameControl.Context) Then
                                Select Case bd.BuildingType
                                    Case eBuildingType.Apartment, eBuildingType.ClubHouse, eBuildingType.Office
                                        FadeScreen(1)
                                        bd.AptMenu.Visible = True
                                        World.RenderingCamera = World.CreateCamera(bd.CameraPos.Position, bd.CameraPos.Rotation, bd.CameraPos.FOV)
                                        HideHud = True
                                        FadeScreen(0)
                                End Select
                            End If
                        End If
                    End If

                    'Open Garage Menu
                    If bd.GarageDistance <= 5.0F Then
                        If Not MenuPool.IsAnyMenuOpen Then
                            ShowHelp(Game.GetLocalizedString("MP_PROP_BUZZ1B"))
                            If Game.IsControlJustReleased(GameControl.Context) Then
                                FadeScreen(1)
                                bd.GrgMenu.Visible = True
                                World.RenderingCamera = World.CreateCamera(bd.CameraPos.Position, bd.CameraPos.Rotation, bd.CameraPos.FOV)
                                HideHud = True
                                FadeScreen(0)
                            End If
                        End If
                    End If

                    'Draw circle
                    If bd.EntranceDistance <= 300.0F AndAlso Not bd.BuildingInPos = QuaternionZero() AndAlso Not bd.BuildingType = eBuildingType.Garage Then bd.BuildingInPos.ToVector3.DrawMarker
                    If bd.GarageDistance <= 300.0F AndAlso Not bd.GarageFootInPos = QuaternionZero() Then bd.GarageFootInPos.ToVector3.DrawMarker

                    If debugMode Then
                        'Debug Circle
                        If bd.EntranceDistance <= 1000.0F Then
                            If Not bd.BuildingLobby = QuaternionZero() Then bd.BuildingLobby.ToVector3.DrawMarker(Color.LightPink, text:="Lobby")
                            If Not bd.BuildingOutPos = QuaternionZero() Then bd.BuildingOutPos.ToVector3.DrawMarker(Color.Red, text:="Out Pos")
                        End If
                        If bd.GarageDistance <= 1000.0F Then
                            If Not bd.GarageInPos = Vector3.Zero Then bd.GarageInPos.DrawMarker(Color.Orange, text:="Car in Pos")
                            If Not bd.GarageFootOutPos = QuaternionZero() Then bd.GarageFootOutPos.ToVector3.DrawMarker(Color.Yellow, text:="Foot out Pos")
                            If Not bd.GarageOutPos = QuaternionZero() Then bd.GarageOutPos.ToVector3.DrawMarker(Color.Green, text:="Car out Pos")
                            If Not bd.GarageWaypoint = QuaternionZero() Then bd.GarageWaypoint.ToVector3.DrawMarker(Color.Indigo, text:="Garage waypoint")
                        End If

                        For a As Integer = 0 To bd.Apartments.Count - 1
                            Dim apt As ApartmentClass = bd.Apartments(a)
                            If apt.ExitDistance <= 3000.0F Then
                                If Not apt.ApartmentDoorPos = QuaternionZero() Then apt.ApartmentDoorPos.ToVector3.DrawMarker(Color.Red, text:=$"Door Pos {apt.FriendlyName}")
                                If Not apt.ApartmentInPos = Vector3.Zero Then apt.ApartmentInPos.DrawMarker(Color.Green, text:=$"Teleport in Pos {apt.FriendlyName}")
                                If Not apt.ApartmentOutPos = Vector3.Zero Then apt.ApartmentOutPos.DrawMarker(Color.Blue, text:=$"Exit Pos {apt.FriendlyName}")
                                If Not apt.WardrobePos = QuaternionZero() Then apt.WardrobePos.ToVector3.DrawMarker(Color.Purple, text:=$"Wardrobe Pos {apt.FriendlyName}")
                                If Not apt.SavePos = Vector3.Zero Then apt.SavePos.DrawMarker(Color.Pink, text:=$"Save Pos {apt.FriendlyName}")
                            End If
                        Next
                    End If
                Next

                'When Player is in any interior (uma unica vez por frame; antes rodava uma vez por predio)
                If ApartmentManager.IsAtHome() Then
                    'Hide Building Exteriors
                    If HighEndApartment.Building IsNot Nothing Then HighEndApartment.Building.HideExterior()

                    If TwoCarGarage.Apartment IsNot Nothing Then TwoCarGarageOnTick()
                    If SixCarGarage.Apartment IsNot Nothing Then SixCarGarageOnTick()
                    If TenCarGarage.Apartment IsNot Nothing Then TenCarGarageOnTick()

                    If MediumEndApartment.Apartment IsNot Nothing Then MediumEndApartmentOnTick()
                    If LowEndApartment.Apartment IsNot Nothing Then LowEndApartmentOnTick()

                    Game.DisableControlThisFrame(GameControl.CharacterWheel)
                    Game.DisableControlThisFrame(GameControl.SelectCharacterFranklin)
                    Game.DisableControlThisFrame(GameControl.SelectCharacterMichael)
                    Game.DisableControlThisFrame(GameControl.SelectCharacterTrevor)
                    Game.DisableControlThisFrame(GameControl.SelectCharacterMultiplayer)
                End If

                If HighEndApartment.Building IsNot Nothing Then HighEndApartmentOnTick()

                'Run Telly & Radio Script
                Select Case PI
                    Case TenCarGarage.Interior.GetInterior, SixCarGarage.Interior.GetInterior, TwoCarGarage.Interior.GetInterior, LowEndApartment.Interior.GetInterior, MediumEndApartment.Interior.GetInterior
                        PropOnTick()
                End Select

                'Hide vehicle blip
                If PP.LastVehicle.IsPersonalVehicle Then
                    If PP.IsInVehicle() Then
                        If PP.LastVehicle.AttachedBlip.Alpha = 255 Then PP.LastVehicle.AttachedBlip.Alpha = 0
                    Else
                        If PP.LastVehicle.AttachedBlip.Alpha = 0 Then PP.LastVehicle.AttachedBlip.Alpha = 255
                    End If
                End If

                MenuPool.ProcessMenus()
                BigMessages.Process()
                iFruit.Update()
            End If

            'debug only
            If debugMode Then
                Debug()
                If Player.IsAiming Then
                    Dim prop = Player.TargetedEntity
                    If prop = Nothing Then
                        debug3rdLine = "Nothing to show"
                    Else
                        debug3rdLine = $"New Door({prop.Model.Hash}, New Vector3({prop.Position.X}F, {prop.Position.Y}F, {prop.Position.Z}F))"
                    End If
                End If
            End If

            If NewFunc.IsCheating("spadebug") Then debugMode = Not debugMode
            If NewFunc.IsCheating("spadebugcam") Then DebugCamera.Toggle()
        Catch ex As Exception
            Logger.Log($"{ex.Message} {ex.StackTrace}")
        End Try
    End Sub

    Private Sub SPA2_Aborted(sender As Object, e As EventArgs) Handles Me.Aborted
        ApartmentManager.Shutdown()

        For Each vehicle In outVehicleList.ToList()
            Try
                If vehicle IsNot Nothing AndAlso vehicle.Exists() Then
                    If vehicle.AttachedBlip IsNot Nothing Then vehicle.AttachedBlip.Delete()
                    vehicle.Delete()
                End If
            Catch ex As Exception
                Logger.Log($"Aborted vehicle cleanup: {ex.Message}")
            End Try
        Next
        outVehicleList.Clear()

        iFruit.Contacts.Remove(MechanicContact)
        iFruit.Contacts.Remove(InsuranceContact)

        TwoCarGarage.Clear()
        SixCarGarage.Clear()
        TenCarGarage.Clear()
        LowEndApartment.Clear()
        MediumEndApartment.Clear()

        If Not RadioEmitter = Nothing Then RadioEmitter.Delete()

        World.RenderingCamera = Nothing
        World.DestroyAllCameras()
    End Sub

    Private Sub SPA2_KeyDown(sender As Object, e As KeyEventArgs) Handles Me.KeyDown
        If debugMode Then
            If Game.IsKeyPressed(Keys.Up) Then
                If Game.Player.Character.IsInVehicle Then
                    Dim gpccvp = Game.Player.Character.CurrentVehicle.Position
                    Logger.Logg($"New Vector3({gpccvp.X}F, {gpccvp.Y}F, {gpccvp.Z}F)")
                Else
                    Dim gpcp = Game.Player.Character.Position
                    Logger.Logg($"New Vector3({gpcp.X}F, {gpcp.Y}F, {gpcp.Z - 1.0F}F)")
                End If
                GTA.UI.Screen.ShowSubtitle("Position copied")
            End If

            If Game.IsKeyPressed(Keys.Down) Then
                If Game.Player.Character.IsInVehicle Then
                    Dim gpccvp = Game.Player.Character.CurrentVehicle.Position
                    Dim cvhead = Game.Player.Character.CurrentVehicle.Heading
                    Logger.Logg($"New Quaternion({gpccvp.X}F, {gpccvp.Y}F, {gpccvp.Z}F, {cvhead}F)")
                Else
                    Dim gpcp = Game.Player.Character.Position
                    Dim head = Game.Player.Character.Heading
                    Logger.Logg($"New Quaternion({gpcp.X}F, {gpcp.Y}F, {gpcp.Z - 1.0F}F, {head}F)")
                End If
                GTA.UI.Screen.ShowSubtitle("Quaternion copied")
            End If

            If Game.IsKeyPressed(Keys.Left) Then
                If DebugCamera.IsEnabled Then
                    Dim cam = DebugCamera.Camera
                    Logger.Logg($"New CameraPRH(New Vector3({cam.Position.X}F, {cam.Position.Y}F, {cam.Position.Z}F), New Vector3({cam.Rotation.X}F, {cam.Rotation.Y}F, {cam.Rotation.Z}F), {cam.FieldOfView}F)")
                    GTA.UI.Screen.ShowSubtitle("Gameplay camera copied")
                End If
            End If

            If Game.IsKeyPressed(Keys.Right) Then
                Logger.Logg(debug3rdLine)
                GTA.UI.Screen.ShowSubtitle("Prop captured")
            End If

            If Game.IsKeyPressed(Keys.Delete) Then
                DebugCamera.Toggle()
            End If

            If Game.IsKeyPressed(Keys.End) Then
                DebugMenu.Visible = True
            End If
        End If
    End Sub

End Class
